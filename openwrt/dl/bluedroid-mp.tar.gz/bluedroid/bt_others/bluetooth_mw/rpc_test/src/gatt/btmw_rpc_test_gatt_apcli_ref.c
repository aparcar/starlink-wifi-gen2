#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "btmw_rpc_test_config.h"
#if CONFIG_USER_GATT_APCLI
#include "btmw_rpc_test_apcli_ref.h"
#include "btmw_rpc_test_debug.h"
#include "btmw_rpc_test_gatt_if.h"
#include "btmw_rpc_test_gattc_if.h"
#include "btmw_rpc_test_gatts_if.h"

#include "u_bt_mw_types.h"
#include "mtk_bt_service_gattc_wrapper.h"
#include "mtk_bt_service_gatts_wrapper.h"
#include "u_bt_mw_common.h"
#include "u_bt_mw_gatt.h"
#include "mtk_bt_service_gap_wrapper.h"

/* APCLI related definition ------------------------------------------------ */
#define APCLI_GAP_DEV_NAME  "BLE AP Client Setup"
/* Define the UUID of the apcli gatt client */
#define APCLI_GATTC_UUID    "DFCC9C22-6FAA-4079-93F0-73A8BB44DEC9"
/* Define the UUID of the apcli gatt server */
#define APCLI_GATTS_UUID    "DFA09C22-6FAA-4079-93F0-73A8BB44DEC9"
/* Default AP Client interface for configuration */
#define APCLI_IF            "apcli0"
#define SITE_SURVEY_RESULT_PATH "/tmp/ssr"
#define NVRAM_GET_RESULT_PATH   "/tmp/gatt_apcli_nvram"
#define AP_LIST_DATA_LEN_MAX    128
#define AP_SSID_LEN_MAX         (32 + 4) // 4*'\0'
#define AP_MODE_LEN             16
#define AP_WPAPSK_MAX           (63 + 1) // 1*'\0'
#define AP_WPAPSK_MIN           (8 + 4) // 4*'\0'
#define APCLI_NOTIFY_LEN_MAX    128
#define LINE_SIZE               256
#define ADVERTISING_CHANNEL_ALL 7  //ADVERTISING_CHANNEL_37 | ADVERTISING_CHANNEL_38 | ADVERTISING_CHANNEL_39;

/* TODO: Register this list when add/delete a characteristic */
enum apcli_char_idx
{
    AP_LIST = 0,
    AP_SSID,
    AP_AUTHMODE,
    AP_ENCRYPTYPE,
    AP_WPAPSK,
    AP_CHANNEL,
    SUBMIT,
    NOTIFY_MSG,
    APCLI_CHAR_NUM
};

/* TODO: CONFIG_GATT_APCLI_USE_SYNC_API have not tested yet */
#if defined(CONFIG_GATT_APCLI_USE_SYNC_API)
const static INT32 gatt_apcli_use_sync_api = 1;
#else
const static INT32 gatt_apcli_use_sync_api = 0;
#endif

/* Global Variable ---------------------------------------------------------- */
INT32 apcli_desc_init_seq;
enum apcli_char_idx apcli_char_init_seq;
struct app_char_data *apcli_msg_char = NULL;

/* APCLI functions for app action ------------------------------------------- */
static CHAR *apcli_on_submit(struct app_char_data *char_data, INT32 offset, CHAR *value, INT32 len);
static CHAR *apcli_set_channel(struct app_char_data *char_data, INT32 offset, CHAR *value, INT32 len);
static CHAR *apcli_get_aplist(struct app_char_data *char_data, INT32 offset);
static VOID apcli_submit_disconnect(struct app_char_data *char_data);

/* APCLI profile declaration ----------------------------------------------- */
struct app_gatt_profile_data gatt_apcli =
{
    .client = {
        .client_if = 0,
        .uuid = APCLI_GATTC_UUID,
        .min_interval = 1000,
        .max_interval = 1000,
        .adv_type = 0,
        .chnl_map = ADVERTISING_CHANNEL_ALL,
        .tx_power = 1,
        .timeout = 0,
        .set_scan_rsp = 0,
        .include_name = 1,
        .incl_txpower = 0,
        .appearance = 0,
        .manufacturer_len = 0,
        .manufacturer_data = NULL,
        .service_data_len = 0,
        .service_data = NULL,
        .service_uuid_len = 0,
        .service_uuid = NULL,
    },
    .server = { // server
        .server_if = 0,
        .conn_id = -1,
        .uuid = APCLI_GATTS_UUID,
    },
    .service = {
        .handle = 0,
        //.uuid = "B7568B11-6FAA-4079-93F0-73A8BB44DEC9",
        .uuid = "DFB0",
        .handle_num = 32,
        //.handle_num = 8,
        .is_primary = 1
    },
    .char_num = APCLI_CHAR_NUM,
    .chars = {
        {
            // AP_LIST
            .status = GATT_ENABLED,
            .handle = 0,
            .uuid = "FF00",
            .property = 2,       //read
            .permission = 1,     //read
            .max_len = AP_LIST_DATA_LEN_MAX,
            .value = NULL,
            .desc_num = 1,
            .desc = {
                {
                    .status = GATT_ENABLED,
                    .handle = 0,
                    .uuid = "2901",
                    .permission = 17,     //read, write
                    .max_len = APP_DESC_LEN_MAX,
                    .value = "AP List"
                },
            },
            .action = {
                .read = apcli_get_aplist,
            },
        },
        {
            // AP_SSID
            .status = GATT_ENABLED,
            .handle = 0,
            .uuid = "FF01",
            .property = 10,       //read, write
            .permission = 17,     //read, write
            .max_len = AP_SSID_LEN_MAX,
            .value = NULL,
            .desc_num = 1,
            .desc = {
                {
                    .status = GATT_ENABLED,
                    .handle = 0,
                    .uuid = "2901",
                    .permission = 17,     //read, write
                    .max_len = APP_DESC_LEN_MAX,
                    .value = "RootAP SSID"
                },
            },
        },
        {
            // AP_AuthMode
            .status = GATT_ENABLED,
            .handle = 0,
            .uuid = "FF02",
            .property = 10,       //read, write
            .permission = 17,     //read, write
            .max_len = AP_MODE_LEN,
            .value = NULL,
            .desc_num = 1,
            .desc = {
                {
                    .status = GATT_ENABLED,
                    .handle = 0,
                    .uuid = "2901",
                    .permission = 17,     //read, write
                    .max_len = APP_DESC_LEN_MAX,
                    .value = "AuthMode 0:OPEN,2:WPAPSK,3:WPA2PSK"
                }
            },
        },
        {
            // AP_EncrypType
            .status = GATT_ENABLED,
            .handle = 0,
            .uuid = "FF03",
            .property = 10,       //read, write
            .permission = 17,     //read, write
            .max_len = AP_MODE_LEN,
            .value = NULL,
            .desc_num = 1,
            .desc = {
                {
                    .status = GATT_ENABLED,
                    .handle = 0,
                    .uuid = "2901",
                    .permission = 17,     //read, write
                    .max_len = APP_DESC_LEN_MAX,
                    .value = "EncrypType 0:NONE,2:TKIP,3:AES"
                }
            },
        },
        {
            // AP_WPAPSK
            .status = GATT_ENABLED,
            .handle = 0,
            .uuid = "FF04",
            .property = 10,       //read, write
            .permission = 17,     //read, write
            .max_len = AP_WPAPSK_MAX,
            .value = NULL,
            .desc_num = 1,
            .desc = {
                {
                    .status = GATT_ENABLED,
                    .handle = 0,
                    .uuid = "2901",
                    .permission = 17,     //read, write
                    .max_len = APP_DESC_LEN_MAX,
                    .value = "KEY"
                }
            },
        },
        {
            // AP_CHANNEL
            .status = GATT_ENABLED,
            .handle = 0,
            .uuid = "FF06",
            .property = 10,       //read, write
            .permission = 17,     //read, write
            .max_len = AP_MODE_LEN,
            .value = NULL,
            .desc_num = 1,
            .desc = {
                {
                    .status = GATT_ENABLED,
                    .handle = 0,
                    .uuid = "2901",
                    .permission = 17,     //read, write
                    .max_len = APP_DESC_LEN_MAX,
                    .value = "Change APCLI Channel immediately"
                },
            },
            .action = {
                .write = apcli_set_channel,
            },
        },
        {
            // APCLI_Submit
            .status = GATT_ENABLED,
            .handle = 0,
            .uuid = "FF05",
            .property = 10,       //read:2, write:8
            .permission = 17,     //read:1, write:16
            .max_len = AP_MODE_LEN,
            .value = NULL,
            .desc_num = 1,
            .desc = {
                {
                    .status = GATT_ENABLED,
                    .handle = 0,
                    .uuid = "2901",
                    .permission = 17,     //read, write
                    .max_len = APP_DESC_LEN_MAX,
                    .value = "Submit 0:Idle, 1:Connect, 2:Disconnect"
                }
            },
            .action = {
                .write = apcli_on_submit,
                .disconnect = apcli_submit_disconnect,
            },
        },
        {
            // APCLI_Message
            .status = GATT_ENABLED,
            .handle = 0,
            .uuid = "FF07",
            .property = 18,       //read:2, Notify:16
            .permission = 1,      //read
            .max_len = AP_LIST_DATA_LEN_MAX,
            .value = NULL,
            .desc_num = 2,
            .desc = {
                {
                    .status = GATT_ENABLED,
                    .handle = 0,
                    .uuid = "2901",
                    .permission = 17,     //read, write
                    .max_len = APP_DESC_LEN_MAX,
                    .value = "Status"
                },
                {
                    .status = GATT_ENABLED,
                    .handle = 0,
                    .uuid = "2902",
                    .permission = 17,     //read, write
                    .max_len = APP_DESC_LEN_MAX,
                    .value = "0"
                }
            },
        }
    }
};

static INT32 vsystem(const CHAR *cmd)
{
    pid_t pid;
    INT32 status;
    if (cmd == NULL)
    {
        return 1;
    }
    if ((pid = vfork()) < 0)
    {
        status = -1;
        perror("vsystem.vfork:");
    }
    else if (pid == 0)
    {
        execl("/bin/sh", "sh", "-c", cmd, (CHAR *) 0);
        _exit(127);
    }
    else
    {
        while (waitpid(pid, &status, 0) < 0)
        {
            if (errno != EINTR)
            {
                status = -1;
                break;
            }
        }
    }
    return status;
}

INT32 get_curr_setting_nvram()
{
    CHAR buf[512];
    CHAR curr_value[64];
    INT32 i;
    FILE *fp = NULL;
    BTMW_RPC_TEST_Logi("[GATTS APP] %s()\n", __func__);
    strncpy(buf, "nvram_get ApCliSsid > "NVRAM_GET_RESULT_PATH" && "
            "nvram_get ApCliAuthMode >> "NVRAM_GET_RESULT_PATH" && "
            "nvram_get ApCliEncrypType >> "NVRAM_GET_RESULT_PATH" && "
            "nvram_get ApCliWPAPSK >> "NVRAM_GET_RESULT_PATH" && "
            "nvram_get Channel >> "NVRAM_GET_RESULT_PATH,
            sizeof(buf));
    BTMW_RPC_TEST_Logd("nvram_get cmd=%s\n", buf);
    if (vsystem(buf) < 0)
    {
        BTMW_RPC_TEST_Loge("nvram_get cmd NG\n");
        perror("nvram_get ApClixxx:");
        return -1;
    }
    fp = fopen(NVRAM_GET_RESULT_PATH, "r");
    if (!fp)
    {
        BTMW_RPC_TEST_Loge("Open nvram_get cmd result path:%sNG\n", NVRAM_GET_RESULT_PATH);
        return -1;
    }
    for (i = AP_SSID; i <= AP_CHANNEL; i++)
    {
        if (!fgets(buf, sizeof(buf), fp))
        {
            BTMW_RPC_TEST_Loge("Read nvram_get cmd result[%d] NG\n", i);
            return -1;
        }
        sscanf(buf, "%63s", curr_value);
        if (i == AP_AUTHMODE)
        {
            if (!strncmp(curr_value, "OPEN", sizeof(curr_value)))
                strncpy(gatt_apcli.chars[i].value, "0", gatt_apcli.chars[i].max_len);
            else if (!strncmp(curr_value, "WPAPSK", sizeof(curr_value)))
                strncpy(gatt_apcli.chars[i].value, "2", gatt_apcli.chars[i].max_len);
            else if (!strncmp(curr_value, "WPA2PSK", sizeof(curr_value)))
                strncpy(gatt_apcli.chars[i].value, "3", gatt_apcli.chars[i].max_len);
            else
                strncpy(gatt_apcli.chars[i].value, "0", gatt_apcli.chars[i].max_len);
        }
        else if (i == AP_ENCRYPTYPE)
        {
            if (!strncmp(curr_value, "NONE", sizeof(curr_value)))
                strncpy(gatt_apcli.chars[i].value, "0", gatt_apcli.chars[i].max_len);
            else if (!strncmp(curr_value, "TKIP", sizeof(curr_value)))
                strncpy(gatt_apcli.chars[i].value, "2", gatt_apcli.chars[i].max_len);
            else if (!strncmp(curr_value, "AES", sizeof(curr_value)))
                strncpy(gatt_apcli.chars[i].value, "3", gatt_apcli.chars[i].max_len);
            else
                strncpy(gatt_apcli.chars[i].value, "0", gatt_apcli.chars[i].max_len);
        }
        else
        {
            strncpy(gatt_apcli.chars[i].value, curr_value, gatt_apcli.chars[i].max_len);
        }
    }
    fclose(fp);
    return 0;
}

/* APCLI profile initial functions  ---------------------------------------- */
/* TODO: Sync the apcli status by scripts when start. */
INT32 apcli_gatts_init()
{
    gatt_apcli.chars[AP_LIST].value = malloc(sizeof(CHAR) * AP_LIST_DATA_LEN_MAX);
    gatt_apcli.chars[AP_SSID].value = malloc(sizeof(CHAR) * AP_SSID_LEN_MAX);
    gatt_apcli.chars[AP_AUTHMODE].value = malloc(sizeof(CHAR) * AP_MODE_LEN);
    gatt_apcli.chars[AP_ENCRYPTYPE].value = malloc(sizeof(CHAR) * AP_MODE_LEN);
    gatt_apcli.chars[AP_WPAPSK ].value = malloc(sizeof(CHAR) * AP_WPAPSK_MAX);
    gatt_apcli.chars[SUBMIT].value = malloc(sizeof(CHAR) * AP_MODE_LEN);
    gatt_apcli.chars[AP_CHANNEL].value = malloc(sizeof(CHAR) * AP_MODE_LEN);
    gatt_apcli.chars[NOTIFY_MSG].value = malloc(sizeof(CHAR) * APCLI_NOTIFY_LEN_MAX);
    memset((void *) gatt_apcli.chars[AP_LIST].value, '\0', AP_LIST_DATA_LEN_MAX);
    memset((void *) gatt_apcli.chars[AP_SSID].value, '\0', AP_SSID_LEN_MAX);
    memset((void *) gatt_apcli.chars[AP_AUTHMODE].value, '\0', AP_MODE_LEN);
    memset((void *) gatt_apcli.chars[AP_ENCRYPTYPE].value, '\0', AP_MODE_LEN);
    memset((void *) gatt_apcli.chars[AP_WPAPSK].value, '\0', AP_WPAPSK_MAX);
    memset((void *) gatt_apcli.chars[SUBMIT].value, '\0', AP_MODE_LEN);
    memset((void *) gatt_apcli.chars[AP_CHANNEL].value, '\0', AP_MODE_LEN);
    memset((void *) gatt_apcli.chars[NOTIFY_MSG].value, '\0', APCLI_NOTIFY_LEN_MAX);
    strncpy(gatt_apcli.chars[AP_LIST].value,
            "No Scan Result",
            AP_LIST_DATA_LEN_MAX);
    if (get_curr_setting_nvram() < 0)
    {
        strncpy(gatt_apcli.chars[AP_SSID].value, " ", AP_SSID_LEN_MAX);
        strncpy(gatt_apcli.chars[AP_AUTHMODE].value, "0", AP_MODE_LEN);
        strncpy(gatt_apcli.chars[AP_ENCRYPTYPE].value, "0", AP_MODE_LEN);
        strncpy(gatt_apcli.chars[AP_WPAPSK].value, "12345678", AP_WPAPSK_MAX);
        strncpy(gatt_apcli.chars[AP_CHANNEL].value, "0", AP_MODE_LEN);
    }
    strncpy(gatt_apcli.chars[SUBMIT].value, "0", AP_MODE_LEN);
    strncpy(gatt_apcli.chars[NOTIFY_MSG].value, "Welcome to BLE APCLI setup. Enjoy it", APCLI_NOTIFY_LEN_MAX);
    apcli_msg_char = &gatt_apcli.chars[NOTIFY_MSG];
    if (vsystem("ifconfig "APCLI_IF" up") < 0)
    {
        BTMW_RPC_TEST_Loge("[GATTS APP] %s() ifconfig %d interface up failed. Apcli setting process might not success\n", __func__,
                       APCLI_IF);
    }
    btmw_rpc_apcli_gatts_register_server(0, NULL);
    return 0;
}

INT32 apcli_rpc_gattc_init()
{
    INT32 ret;
    CHAR *devname;
    CHAR *uuid;
    devname = (gatt_apcli.dev_name) ? gatt_apcli.dev_name : APCLI_GAP_DEV_NAME;
    ret = a_mtkapi_bt_gap_set_name(devname);
    if (BT_SUCCESS == ret)
    {
        BTMW_RPC_TEST_Logd("set device name=%s ok!\n", devname);
    }
    uuid = (gatt_apcli.client.uuid) ? gatt_apcli.client.uuid : APCLI_GATTC_UUID;
    a_mtkapi_bt_gattc_register_app(uuid);

    return BT_SUCCESS;
}

/* Copy from makeRequest.c of WebUI */
/* TODO: use scripts to get aplist result */
static void convert_string_display(CHAR *str)
{
    INT32 len, i;
    CHAR buffer[193];
    CHAR *pOut;
    memset(buffer, 0, 193);
    len = strlen(str);
    pOut = &buffer[0];
    for (i = 0; i < len; i++)
    {
        switch (str[i])
        {
        case 38:
            strcpy(pOut, "&amp;");   // '&'
            pOut += 5;
            break;
        case 60:
            strcpy(pOut, "&lt;");   // '<'
            pOut += 4;
            break;
        case 62:
            strcpy(pOut, "&gt;");   // '>'
            pOut += 4;
            break;
        case 34:
            strcpy(pOut, "&#34;");   // '"'
            pOut += 5;
            break;
        case 39:
            strcpy(pOut, "&#39;");   // '''
            pOut += 5;
            break;
        case 32:
            strcpy(pOut, "&nbsp;");   // ' '
            pOut += 6;
            break;
        default:
            if ((str[i] >= 0) && (str[i] <= 31))
            {
                //Device Control Characters
                sprintf(pOut, "&#%02d;", str[i]);
                pOut += 5;
            }
            else if ((str[i] == 39) || (str[i] == 47) || (str[i] == 59) || (str[i] == 92))
            {
                // ' / ; (backslash)
                sprintf(pOut, "&#%02d;", str[i]);
                pOut += 5;
            }
            else if (str[i] >= 127)
            {
                //Device Control Characters
                sprintf(pOut, "&#%03d;", str[i]);
                pOut += 6;
            }
            else
            {
                *pOut = str[i];
                pOut++;
            }
            break;
        }
    }
    *pOut = '\0';
    strcpy(str, buffer);
}

static CHAR *apcli_get_aplist(struct app_char_data *char_data, INT32 offset)
{
    FILE *pp;
    CHAR buf[LINE_SIZE], *ptr;
    CHAR aplist[AP_LIST_DATA_LEN_MAX] = {0};
    CHAR ssid[186], bssid[20], security[23];
    CHAR mode[9], ext_ch[7], net_type[3];
    CHAR wps[4];
    INT32 t_size = 0;
    INT32 len = 0;
    INT32 no = 0;
    INT32 channeld = 0;
    INT32 signald = 0;
    INT32 i, space_start;
    //	CHAR filter[4];
    INT32 total_ssid_num, get_ssid_times, round;
    BTMW_RPC_TEST_Logi("[GATTS APP] %s()\n", __func__);
    if (!char_data)
        return NULL;
    /* read rest original scan result from offset*/
    if (offset != 0)
    {
        INT32 real_offset;
        INT32 vlen = strlen(char_data->value);
        real_offset = (offset > vlen) ? vlen : offset;
        return char_data->value + real_offset;
    }
    /* A new scan request */
    snprintf(buf, sizeof(buf), "iwpriv %s set SiteSurvey=1", APCLI_IF);
    BTMW_RPC_TEST_Logd("system(%s)\n", buf);
    if (vsystem(buf) < 0)
    {
        BTMW_RPC_TEST_Loge("execute iwpriv set SiteSurvey=1 fail!\n");
        perror("execl(set SiteSurvey=1):");
    }
    btmw_rpc_gatts_app_notify(apcli_msg_char, "scanning", sizeof("scanning"));
    /* Wait for SCAN result.
    5 seconds fo 2G + 5G, 2 seconds for 2G
    1 more seconds margen */
    sleep(3);
    sprintf(buf, "iwpriv %s get_site_survey > %s", APCLI_IF, SITE_SURVEY_RESULT_PATH);
    BTMW_RPC_TEST_Logd("system(%s)\n", buf);
    if (vsystem(buf) < 0)
    {
        BTMW_RPC_TEST_Loge("execute get_site_survey fail!\n");
        perror("popen(get_site_survey):");
        return NULL;
    }
    pp = fopen(SITE_SURVEY_RESULT_PATH, "r");
    fgets(buf, sizeof(buf), pp);
    fgets(buf, sizeof(buf), pp);
    ptr = buf;
    total_ssid_num = 0;
    sscanf(ptr, "Total=%d", &total_ssid_num);
    get_ssid_times = (total_ssid_num / 32) + 1;
    BTMW_RPC_TEST_Logd("total_ssid_num=%d, get_ssid_times=%d", total_ssid_num, get_ssid_times);
    fgets(buf, sizeof(buf), pp);
    //TODO: Get more than 1 page of site survey result.
    //INT32 index = 0;
    t_size = sizeof(aplist);
    len += snprintf(aplist + len, t_size - len, "{");
    for (round = 0; round < get_ssid_times; round++)
    {
        if ((t_size - len) < 32)
            break;
        if (round != 0)
        {
            memset(buf, 0, sizeof(buf));
            snprintf(buf, sizeof(buf), "iwpriv %s get_site_survey %d > %s", APCLI_IF, round * 32, SITE_SURVEY_RESULT_PATH);
            if (pp != NULL)
                pclose(pp);
            vsystem(buf);
            pp = fopen(SITE_SURVEY_RESULT_PATH, "r");
            if (!(pp = popen(buf, "r")))
            {
                BTMW_RPC_TEST_Loge("execute get_site_survey round(%d)fail!\n", round);
                return NULL;
            }
            fgets(buf, sizeof(buf), pp);
            fgets(buf, sizeof(buf), pp);
            fgets(buf, sizeof(buf), pp);
        }
        while (fgets(buf, sizeof(buf), pp))
        {
            BTMW_RPC_TEST_Logi("t_size=%d, len=%d\n", t_size, len);
            if (strlen(buf) < 4)
                break;
            if ((t_size - len) < 32)
                break;
            ptr = buf;
            sscanf(ptr, "%d %d ", &no, &channeld);
            ptr += 41;
            sscanf(ptr, "%20s %23s %d %9s %7s %3s %4s", bssid, security, &signald, mode, ext_ch, net_type, wps);
            ptr = buf + 8;
            i = 0;
            while (i < 33)
            {
                if ((ptr[i] == 0x20) && (i == 0 || ptr[i - 1] != 0x20))
                    space_start = i;
                i++;
            }
            ptr[space_start] = '\0';
            strcpy(ssid, buf + 8);
            convert_string_display(ssid);
            len += snprintf(aplist + len, t_size - len, "\"%d\":{", no);
            len += snprintf(aplist + len, t_size - len, "\"ch\":\"%d\",", channeld);
            len += snprintf(aplist + len, t_size - len, "\"ssid\":\"%s\"},", ssid);
#if 0
            len += snprintf(aplist + len, t_size - len, "\"bssid\":\"%s\",", bssid);
            len += snprintf(aplist + len, t_size - len, "\"security\":\"%s\",", security);
            len += snprintf(aplist + len, t_size - len, "\"signald\":\"%d\",", signald);
            len += snprintf(aplist + len, t_size - len, "\"mode\":\"%s\",", mode);
            len += snprintf(aplist + len, t_size - len, "\"ext_ch\":\"%s\",", ext_ch);
            len += snprintf(aplist + len, t_size - len, "\"net_type\":\"%s\",", net_type);
            len += snprintf(aplist + len, t_size - len, "\"wps\":\"%s\"},", wps);
            if (!strcmp(filter, "WPS"))
            {
                if (!strcmp(wps, "YES"))
                {
                    printf("\"%d\":{", index++);
                    printf("\"channeld\":\"%d\",", channeld);
                    printf("\"ssid\":\"%s\",", ssid);
                    printf("\"bssid\":\"%s\",", bssid);
                    printf("\"security\":\"%s\",", security);
                    printf("\"signald\":\"%d\",", signald);
                    printf("\"mode\":\"%s\",", mode);
                    printf("\"ext_ch\":\"%s\",", ext_ch);
                    printf("\"net_type\":\"%s\",", net_type);
                    printf("\"wps\":\"%s\"},", wps);
                }
            }
            else
            {
                len += snprintf(aplist + len, t_size - len, "\"%d\":{", no);
                len += snprintf(aplist + len, t_size - len, "\"channeld\":\"%d\",", channeld);
                len += snprintf(aplist + len, t_size - len, "\"ssid\":\"%s\",", ssid);
                len += snprintf(aplist + len, t_size - len, "\"bssid\":\"%s\",", bssid);
                len += snprintf(aplist + len, t_size - len, "\"security\":\"%s\",", security);
                len += snprintf(aplist + len, t_size - len, "\"signald\":\"%d\",", signald);
                len += snprintf(aplist + len, t_size - len, "\"mode\":\"%s\",", mode);
                len += snprintf(aplist + len, t_size - len, "\"ext_ch\":\"%s\",", ext_ch);
                len += snprintf(aplist + len, t_size - len, "\"net_type\":\"%s\",", net_type);
                len += snprintf(aplist + len, t_size - len, "\"wps\":\"%s\"},", wps);
            }
#endif
        }
    }
    len += snprintf(aplist + len - 1, t_size - len + 1, "}");   //replace latest ',' by '}'
    btmw_rpc_gatts_app_notify(apcli_msg_char, "scan complete", sizeof("scan complete"));
    BTMW_RPC_TEST_Logd("aplist=%s, t_size=%d, len=%d\n", aplist, t_size, len);
    strncpy(char_data->value, aplist, char_data->max_len);
    if (pp)
        fclose(pp);
    return char_data->value;
}

static INT32 connect_to_rootap(CHAR *ssid, INT32 authmode, INT32 encryptype, CHAR *wpapsk)
{
    CHAR cmd[512] = {0};
    CHAR *buf = cmd;
    CHAR authmode_str[16] = {0};
    CHAR encryptype_str[8] = {0};
    INT32 len = 0;
    INT32 t_len = sizeof(cmd);
    /* sanity check */
    if (!ssid || !wpapsk)
        return -1;
    BTMW_RPC_TEST_Logi("[GATTS APP] %s()\n", __func__);
    BTMW_RPC_TEST_Logi("[GATTS APP] ssid=%s, authmode=%d, encryptype=%d, wpapsk=%s\n", ssid, authmode, encryptype, wpapsk);
    if (authmode < 0 || authmode > 3)
        return -1;
    if (encryptype < 0 || encryptype > 3)
        return -1;
    switch (authmode)
    {
    case 0:
        strncpy(authmode_str, "OPEN", sizeof(authmode_str));
        break;
    case 2:
        strncpy(authmode_str, "WPAPSK", sizeof(authmode_str));
        break;
    case 3:
        strncpy(authmode_str, "WPA2PSK", sizeof(authmode_str));
        break;
    default:
        strncpy(authmode_str, "OPEN", sizeof(authmode_str));
    };
    switch (encryptype)
    {
    case 0:
        strncpy(encryptype_str, "NONE", sizeof(encryptype_str));
        break;
    case 2:
        strncpy(encryptype_str, "TKIP", sizeof(encryptype_str));
        break;
    case 3:
        strncpy(encryptype_str, "AES", sizeof(encryptype_str));
        break;
    default:
        strncpy(encryptype_str, "NONE", sizeof(encryptype_str));
    };
    len += snprintf(buf + len, t_len - len, "iwpriv %s set ApCliEnable=0;", APCLI_IF);
    len += snprintf(buf + len, t_len - len, "iwpriv %s set ApCliAuthMode=%s;", APCLI_IF, authmode_str);
    len += snprintf(buf + len, t_len - len, "iwpriv %s set ApCliEncrypType=%s;", APCLI_IF, encryptype_str);
    len += snprintf(buf + len, t_len - len, "iwpriv %s set ApCliSsid=%s;", APCLI_IF, ssid);
    len += snprintf(buf + len, t_len - len, "iwpriv %s set ApCliWPAPSK=%s;", APCLI_IF, wpapsk);
    len += snprintf(buf + len, t_len - len, "iwpriv %s set ApCliSsid=%s;", APCLI_IF, ssid);
    len += snprintf(buf + len, t_len - len, "iwpriv %s set ApCliEnable=1", APCLI_IF);
    if (t_len <= len)
    {
        cmd[len - 1] = '\0';
        BTMW_RPC_TEST_Loge("apcli cmd is too long: %s\n", cmd);
        return -1;
    }
    BTMW_RPC_TEST_Logd("apcli cmd: %s\n", cmd);
    if (vsystem(cmd) < 0)
    {
        BTMW_RPC_TEST_Loge("execute %s fail!\n", cmd);
        perror("connect_to_rootap:");
        return -1;
    }
    len = 0;
    memset(cmd, 0, sizeof(cmd));
    buf = cmd;
    len += snprintf(buf + len, t_len - len, "nvram_set ApCliSsid %s && ", ssid);
    len += snprintf(buf + len, t_len - len, "nvram_set ApCliAuthMode %s && ", authmode_str);
    len += snprintf(buf + len, t_len - len, "nvram_set ApCliEncrypType %s && ", encryptype_str);
    len += snprintf(buf + len, t_len - len, "nvram_set ApCliWPAPSK %s", wpapsk);
    if (t_len <= len)
    {
        cmd[ len - 1 ] = '\0';
        BTMW_RPC_TEST_Loge("nvram_set cmd is too long: %s\n", cmd);
        return -1;
    }
    BTMW_RPC_TEST_Logd("nvram_set cmd: %s\n", cmd);
    if (vsystem(cmd) < 0)
    {
        BTMW_RPC_TEST_Loge("execute %s fail!\n", cmd);
        perror("nvram_set ApClixxx:");
        return -1;
    }
    return 0;
}

static INT32 disconnect_to_rootap()
{
    CHAR cmd[64] = {0};
    snprintf(cmd, sizeof(cmd), "iwpriv %s set ApCliEnable=0", APCLI_IF);
    if (vsystem(cmd) < 0)
    {
        BTMW_RPC_TEST_Loge("execute %s fail!\n", cmd);
        perror("disconnect_to_rootap:");
        return -1;
    }
    return 0;
}

/*TODO do real one by scripts... */
static INT32 is_apcli_connected()
{
    sleep(5);
    return 1;
}

static INT32 switch_channel(INT32 channel)
{
    CHAR cmd[128] = {0};
    INT32 len;
    INT32 t_len = sizeof(cmd);
    len = 0;
    len += snprintf(cmd + len, t_len - len, "iwpriv %s set Channel=%d", APCLI_IF, channel);
    len += snprintf(cmd + len, t_len - len, "nvram_set Channel %d", channel);
    if (vsystem(cmd) < 0)
    {
        BTMW_RPC_TEST_Loge("execute %s fail!\n", cmd);
        perror("apcli switch_channel:");
        return -1;
    }
    return 0;
}

static CHAR *apcli_on_submit(struct app_char_data *char_data, INT32 offset, CHAR *value, INT32 len)
{
    BTMW_RPC_TEST_Logi("[GATTS APP] %s()\n", __func__);
    if (!char_data || !value)
        return NULL;
    if (!strncmp("1", value, len))
    {
        connect_to_rootap(gatt_apcli.chars[AP_SSID].value,
                          (int) strtol(gatt_apcli.chars[AP_AUTHMODE].value, NULL, 10),
                          (int) strtol(gatt_apcli.chars[AP_ENCRYPTYPE].value, NULL, 10),
                          gatt_apcli.chars[AP_WPAPSK].value);
        if (is_apcli_connected())
            btmw_rpc_gatts_app_notify(apcli_msg_char, "connected", sizeof("connected"));
        else
            btmw_rpc_gatts_app_notify(apcli_msg_char, "connect failed", sizeof("connect failed"));
    }
    else if (!strncmp("2", value, len))
    {
        if (disconnect_to_rootap() < 0)
            btmw_rpc_gatts_app_notify(apcli_msg_char, "disconnect failed", sizeof("disconnect failed"));
        else
            btmw_rpc_gatts_app_notify(apcli_msg_char, "disconnected", sizeof("disconnected"));
    }
    else
    {
        btmw_rpc_gatts_app_notify(apcli_msg_char, "idle", sizeof("idle"));
    }
    return NULL;
}

static CHAR *apcli_set_channel(struct app_char_data *char_data, INT32 offset, CHAR *value, INT32 len)
{
    BTMW_RPC_TEST_Logi("[GATTS APP] %s()\n", __func__);
    INT32 max_len;
    CHAR notify_str[64];
    if (!char_data || !value)
        return NULL;
    max_len = char_data->max_len;
    max_len = (max_len > offset + len + 1) ? len + 1 : max_len - offset;
    strncpy(char_data->value + offset, value, max_len);
    /* prevent string overflow */
    char_data->value[ max_len - 1 ] = '\0';
    /*TODO: need a client can send prepare write to confirm the design */
    if (offset == 0)
    {
        switch_channel(strtol(char_data->value, NULL, 10));
        snprintf(notify_str, sizeof(notify_str), "switch %s channel to %s", APCLI_IF, char_data->value);
        btmw_rpc_gatts_app_notify(apcli_msg_char, notify_str, strlen(notify_str) + 1);
    }
    return char_data->value + offset;
}

static VOID apcli_submit_disconnect(struct app_char_data *char_data)
{
    strncpy(char_data->value, "0", char_data->max_len);
}

static CHAR *gatt_apcli_desc_read(INT32 handle, INT32 offset)
{
    INT32 i, j;
    INT32 len;
    INT32 real_offset = 0;
    BTMW_RPC_TEST_Logi("[GATTS APP] %s()\n", __func__);
    for (i = AP_LIST; i < APP_CHAR_MAX_NUM; i++)
    {
        if (gatt_apcli.chars[i].status != GATT_ENABLED)
            continue;
        for (j = 0; j < APP_DESC_MAX_NUM; j++)
        {
            if (gatt_apcli.chars[i].desc[j].status != GATT_ENABLED)
                continue;
            if (gatt_apcli.chars[i].desc[j].handle == handle)
            {
                BTMW_RPC_TEST_Logd("[GATTS APP] Read from desc: handle = %d, char# = %d, desc# = %d, value = %s\n",
                               handle, i, j, gatt_apcli.chars[i].desc[j].value);
                len = strlen(gatt_apcli.chars[i].desc[j].value);
                real_offset = (offset > len) ? len : offset;
                BTMW_RPC_TEST_Logd("[GATTS APP] real_offset = %d real_value = %s\n",
                               real_offset,
                               gatt_apcli.chars[i].desc[j].value + real_offset);
                return gatt_apcli.chars[i].desc[j].value + real_offset;
            }
        }
    }
    return NULL;
}

static CHAR *gatt_apcli_desc_write(INT32 handle, CHAR *value, INT32 len)
{
    INT32 i, j, max_len;
    BTMW_RPC_TEST_Logi("[GATTS APP] %s()\n", __func__);
    for (i = AP_LIST; i < APP_CHAR_MAX_NUM; i++)
    {
        if (gatt_apcli.chars[i].status != GATT_ENABLED)
            continue;
        for (j = 0; j < APP_DESC_MAX_NUM; j++)
        {
            if (gatt_apcli.chars[i].desc[j].status != GATT_ENABLED)
                continue;
            if (gatt_apcli.chars[i].desc[j].handle == handle)
            {
                BTMW_RPC_TEST_Logd("[GATTS APP] Write to desc: handle = %d, char# = %d, desc# = %d, old_value = %s new_value[%d] = %s\n",
                               handle, i, j, gatt_apcli.chars[i].desc[j].value, len, value);
                max_len = gatt_apcli.chars[i].desc[j].max_len;
                max_len = (max_len > len + 1) ? len + 1 : max_len;
                strncpy(gatt_apcli.chars[i].desc[j].value, value, max_len);
                /* prevent string overflow */
                gatt_apcli.chars[i].desc[j].value[max_len - 1] = '\0';
                return gatt_apcli.chars[i].desc[j].value;
            }
        }
    }
    return NULL;
}

static CHAR *gatt_apcli_char_read(INT32 handle, INT32 offset)
{
    INT32 i;
    CHAR *ret = NULL;
    INT32 len;
    INT32 real_offset;
    BTMW_RPC_TEST_Logi("[GATTS APP] %s()\n", __func__);
    for (i = AP_LIST; i < APP_CHAR_MAX_NUM; i++)
    {
        if (gatt_apcli.chars[i].status != GATT_ENABLED)
            continue;
        if (gatt_apcli.chars[i].handle == handle)
        {
            BTMW_RPC_TEST_Logd("[GATTS APP] Read from char: handle = %d, char# = %d, value = %s\n",
                           handle, i, gatt_apcli.chars[ i ].value);
            len = strlen(gatt_apcli.chars[i].value);
            real_offset = (offset > len) ? len : offset;
            if (gatt_apcli.chars[i].action.read)
                ret = gatt_apcli.chars[i].action.read(&gatt_apcli.chars[i], real_offset);
            if (ret)
                return ret;
            /*
            if (!ret)
                ret =  gatt_apcli.chars[i].value;
            */
            BTMW_RPC_TEST_Logd("[GATTS APP] real_offset = %d real_value = %s\n",
                           real_offset,
                           gatt_apcli.chars[i].value + real_offset);
            return gatt_apcli.chars[i].value + real_offset;
        }
    }
    return NULL;
}

static CHAR *gatt_apcli_char_write(INT32 handle, INT32 offset, CHAR *value, INT32 len)
{
    INT32 i, max_len;
    CHAR *ret = NULL;
    INT32 real_offset;
    BTMW_RPC_TEST_Logi("[GATTS APP] %s()\n", __func__);
    for (i = AP_LIST; i < APP_CHAR_MAX_NUM; i++)
    {
        if (gatt_apcli.chars[i].status != GATT_ENABLED)
            continue;
        if (gatt_apcli.chars[i].handle == handle)
        {
            BTMW_RPC_TEST_Logd("[GATTS APP] Write to char : handle = %d, char# = %d, old_value = %s, new_value[%d] = %s\n",
                           handle, i, gatt_apcli.chars[i].value, len , value);
            real_offset = (offset > gatt_apcli.chars[i].max_len) ?
                          gatt_apcli.chars[i].max_len : offset;
            if (gatt_apcli.chars[i].action.write)
                ret = gatt_apcli.chars[i].action.write(&gatt_apcli.chars[i],
                        real_offset, value, len);
            if (ret)
            {
                BTMW_RPC_TEST_Logd("[GATTS APP] real_offset = %d real_value = %s\n",
                               real_offset,
                               ret + real_offset);
                return ret;
            }
            max_len = gatt_apcli.chars[i].max_len;
            max_len = (max_len > real_offset + len + 1) ? len + 1 : max_len - real_offset;
            strncpy(gatt_apcli.chars[i].value + real_offset, value, max_len);
            /* prevent string overflow */
            gatt_apcli.chars[i].value[max_len - 1] = '\0';
            BTMW_RPC_TEST_Logd("[GATTS APP] real_offset = %d real_value = %s\n",
                           real_offset,
                           gatt_apcli.chars[i].value + real_offset);
            return gatt_apcli.chars[i].value + real_offset;
        }
    }
    return NULL;
}

static VOID gatt_apcli_char_connect()
{
    INT32 i;
    for (i = AP_LIST; i < APP_CHAR_MAX_NUM; i++)
    {
        if (gatt_apcli.chars[i].status != GATT_ENABLED)
            continue;
        if (gatt_apcli.chars[i].action.connect)
            gatt_apcli.chars[i].action.connect(&gatt_apcli.chars[i]);
    }
}

static VOID gatt_apcli_char_disconnect()
{
    INT32 i;
    for (i = AP_LIST; i < APP_CHAR_MAX_NUM; i++)
    {
        if (gatt_apcli.chars[i].status != GATT_ENABLED)
            continue;
        if (gatt_apcli.chars[i].action.disconnect)
            gatt_apcli.chars[i].action.disconnect(&gatt_apcli.chars[i]);
    }
}

/* Define btmw-test command handler ---------------------------------------- */
INT32 btmw_rpc_apcli_gatts_register_server(INT32 argc, CHAR **argv)
{
    INT32 len;
    BTMW_RPC_TEST_Logi("[GATTS APP] %s()\n", __func__);
    if (argc == 1)
    {
        len = sizeof(gatt_apcli.server.uuid);
        memset(gatt_apcli.server.uuid, 0, len);
        strncpy(gatt_apcli.server.uuid, argv[0], strlen(gatt_apcli.server.uuid));
        gatt_apcli.server.uuid[len - 1] = '\0';
    }
    if (!gatt_apcli_use_sync_api)
    {
        apcli_char_init_seq = 0;
        apcli_desc_init_seq = 0;
        if (a_mtkapi_bt_gatts_register_server(gatt_apcli.server.uuid))
        {
            BTMW_RPC_TEST_Loge("[GATTS APP] %s() a_mtkapi_bt_gatts_register_server NG\n", __func__);
            return BT_ERR_STATUS_FAIL;
        }
        return BT_SUCCESS;
    }

    return BT_SUCCESS;
}

/* APP hook function for btmw gatt ----------------------------------------- */
static INT32 cal_handle_num(struct app_gatt_profile_data *gatts_data)
{
    INT32 c_num = 0;
    INT32 d_num = 0;
    INT32 h_num = 0;
    INT32 i, j;
    BTMW_RPC_TEST_Logi("[GATTS APP] %s()\n", __func__);
    if (!gatts_data)
    {
        BTMW_RPC_TEST_Loge("[GATTS APP] %s() gatts_data is NULL\n", __func__);
        return 0;
    }
    for (i = 0; i < APCLI_CHAR_NUM; i++, d_num = 0)
    {
        if (gatts_data->chars[i].status != GATT_ENABLED)
            continue;
        for (j = 0; j < APP_DESC_MAX_NUM; j++)
        {
            if (gatts_data->chars[i].desc[j].status != GATT_ENABLED)
                break;
            d_num++;
        }
        BTMW_RPC_TEST_Logd("[GATTS APP] chars[%d].desc_num=%d, cal d_num=%d\n",
                       i, gatts_data->chars[i].desc_num, d_num);
        gatts_data->chars[i].desc_num = d_num;
        /* (GATT Characteristic Declaration UUID 0x2803 + chars[i].uuid) + d_num */
        h_num += 2 + d_num;
        c_num ++;
    }
    BTMW_RPC_TEST_Logd("[GATTS APP] gatts_data.char_num=%d, cal c_num=%d\n",
                   i, gatts_data->char_num, c_num);
    gatts_data->char_num = c_num;
    return h_num;
}

INT32 btmw_rpc_gatts_app_init()
{
    BTMW_RPC_TEST_Logi("[GATTS APP] %s()\n", __func__);
    /* apcli gatt app */
    cal_handle_num(&gatt_apcli);
    apcli_gatts_init();
    return BT_SUCCESS;
}

INT32 btmw_rpc_gattc_app_init()
{
    BTMW_RPC_TEST_Logi("[GATTC APP] %s()\n", __func__);
    /* apcli gatt app */
    apcli_rpc_gattc_init();
    return BT_SUCCESS;
}

VOID btmw_rpc_gatts_app_notify(struct app_char_data *char_data, CHAR *value, INT32 len)
{
    INT32 confirm = 0; //notify
    INT32 i, notify_en;
    UINT16 desc_value;
    BTMW_RPC_TEST_Logi("[GATTS APP] %s()\n", __func__);
    if (!char_data || !value)
        return ;
    for (i = 0; i < char_data->desc_num; i++)
    {
        if (!strncmp(char_data->desc[i].uuid, "2902", sizeof("2902")))
        {
            /*
               CCC data is 2 bytes in little endian order
               desc.value[0] = 0x01, desc.value[1] = 0x00 means 0x0001
               0x0001: notification is enabled
            */
            //desc_value  = (UINT8)char_data->desc[i].value[1] << 8;
            //desc_value += (UINT8)char_data->desc[i].value[0];
            desc_value = * (UINT16 *) char_data->desc[i].value;
            notify_en = 0x1 & desc_value;
            break;
        }
    }
    BTMW_RPC_TEST_Logd("[GATTS APP] desc[%d] uuid = %s, desc.value[0] = %d, desc.value[1] = %d, value = %d, notify_en = %d\n",
                   i, char_data->desc[i].uuid,
                   (UINT8) char_data->desc[i].value[0],
                   (UINT8) char_data->desc[i].value[1],
                   desc_value,
                   notify_en);
    if (notify_en)
    {
        a_mtkapi_bt_gatts_send_indication(gatt_apcli.server.server_if,
                                    char_data->handle,
                                    gatt_apcli.server.conn_id,
                                    confirm, value, len);
    }
    return ;
}

/* APP callback function for gatts ----------------------------------------- */
VOID btmw_rpc_gatts_app_event_cbk(BT_GATTS_EVENT_T bt_gatts_event)
{
    BT_GATTS_CONNECT_RST_T conn_rst;
    //INT32 ret;
    switch (bt_gatts_event)
    {
    case BT_GATTS_CONNECT:
        a_mtkapi_bt_gatts_get_connect_result_info(&conn_rst);
        BTMW_RPC_TEST_Logi("[GATTS APP] get_connect_result_info : conn_id = %d, server_if = %d, btaddr = %s\n",
                       conn_rst.conn_id,
                       conn_rst.server_if,
                       conn_rst.btaddr);
        /*
        ret = a_mtkapi_bt_gattc_multi_adv_disable(gatt_apcli.client.client_if);
        if (ret != BT_SUCCESS)
            BTMW_RPC_TEST_Loge("[GATTS APP] Disable advertisement failed\n");
        */
        if (conn_rst.server_if == gatt_apcli.server.server_if)
        {
            gatt_apcli.server.conn_id = conn_rst.conn_id;
            /*
            ret = a_mtkapi_bt_gattc_configure_mtu(conn_rst.conn_id, BT_GATT_MAX_MTU_SIZE);
            if (ret != BT_SUCCESS)
            {
                BTMW_RPC_TEST_Loge("[GATTS APP] a_mtkapi_bt_gattc_configure_mtu(%d, %d) failed, ret=%d\n", conn_rst.conn_id, BT_GATT_MAX_MTU_SIZE, ret);
            }
            */
        }
        gatt_apcli_char_connect();
        break;
    case BT_GATTS_DISCONNECT:
        /*
        ret = c_btm_gattc_multi_adv_enable_sync(gatt_apcli.client.client_if,
                gatt_apcli.client.min_interval,
                gatt_apcli.client.max_interval,
                gatt_apcli.client.adv_type,
                gatt_apcli.client.chnl_map,
                gatt_apcli.client.tx_power,
                gatt_apcli.client.timeout);
        if (ret != BT_SUCCESS)
        {
            BTMW_RPC_TEST_Loge("[GATTS APP] Disable advertisement failed\n");
        }
        */
        gatt_apcli.server.conn_id = -1;
        gatt_apcli_char_disconnect();
        break;
    default:
        BTMW_RPC_TEST_Logi("[GATTS APP] unhandled event:%d\n", bt_gatts_event);
        /* do nothing */
    };
}

VOID btmw_rpc_gattc_app_reg_client_cbk(BT_GATTC_REG_CLIENT_T *pt_reg_client_result)
{
    if (NULL == pt_reg_client_result)
    {
        BTMW_RPC_TEST_Loge("[GATTC] %s(), pt_reg_client_result is NULL\n", __func__);
        return;
    }
    gatt_apcli.client.client_if = pt_reg_client_result->client_if;
    BTMW_RPC_TEST_Logi("[GATTC] %s(), client_if = %d\n", __func__, gatt_apcli.client.client_if);
    a_mtkapi_bt_gattc_multi_adv_enable(gatt_apcli.client.client_if,
                                    gatt_apcli.client.min_interval,
                                    gatt_apcli.client.max_interval,
                                    gatt_apcli.client.adv_type,
                                    gatt_apcli.client.chnl_map,
                                    gatt_apcli.client.tx_power,
                                    gatt_apcli.client.timeout);
}

VOID btmw_rpc_gattc_app_adv_enable_cbk(BT_GATTC_ADV_ENABLED_T *pt_adv_enabled)
{
    BTMW_RPC_TEST_Logi("[GATTC] %s(), status = %ld\n", __func__, (long)pt_adv_enabled->status);
    if (BT_SUCCESS == pt_adv_enabled->status)
    {
        a_mtkapi_bt_gattc_multi_adv_setdata(gatt_apcli.client.client_if,
                                    gatt_apcli.client.set_scan_rsp,
                                    gatt_apcli.client.include_name,
                                    gatt_apcli.client.incl_txpower,
                                    gatt_apcli.client.appearance,
                                    gatt_apcli.client.manufacturer_len,
                                    gatt_apcli.client.manufacturer_data,
                                    gatt_apcli.client.service_data_len,
                                    gatt_apcli.client.service_data,
                                    gatt_apcli.client.service_uuid_len,
                                    gatt_apcli.client.service_uuid);
    }
    else
    {
        BTMW_RPC_TEST_Loge("[GATTC] %s(), adv enable fail\n", __func__);
    }

}

VOID btmw_rpc_gatts_app_reg_server_cbk(BT_GATTS_REG_SERVER_RST_T *bt_gatts_reg_server)
{
    if (gatt_apcli_use_sync_api)
        return ;
    gatt_apcli.server.server_if = bt_gatts_reg_server->server_if;
    BTMW_RPC_TEST_Logd("[GATTS APP] Register server callback : add_service() server_if = %d, uuid =%s, is_primary=%d, handle_num=%d\n",
                   gatt_apcli.server.server_if,
                   gatt_apcli.service.uuid,
                   gatt_apcli.service.is_primary,
                   gatt_apcli.service.handle_num);
    if (a_mtkapi_bt_gatts_add_service(gatt_apcli.server.server_if,
                                gatt_apcli.service.uuid,
                                gatt_apcli.service.is_primary,
                                gatt_apcli.service.handle_num))
    {
        BTMW_RPC_TEST_Loge("[GATTS APP] %s() a_mtkapi_bt_gatts_add_service NG\n", __func__);
    }
    return ;
}

VOID btmw_rpc_gatts_app_add_srvc_cbk(BT_GATTS_ADD_SRVC_RST_T *bt_gatts_add_srvc)
{
    if (gatt_apcli_use_sync_api)
        return ;
    if (bt_gatts_add_srvc->server_if == gatt_apcli.server.server_if)
    {
        gatt_apcli.service.handle = bt_gatts_add_srvc->srvc_handle;
    }
    apcli_char_init_seq = 0;
    BTMW_RPC_TEST_Logd("[GATTS APP] Register service callback : server_if = %d, handle = %d, uuid = %s, inst_id = %d, property = %d, permission = %d\n",
                   gatt_apcli.server.server_if,
                   gatt_apcli.service.handle,
                   gatt_apcli.chars[apcli_char_init_seq].uuid,
                   gatt_apcli.chars[apcli_char_init_seq].property,
                   gatt_apcli.chars[apcli_char_init_seq].permission);
    if (a_mtkapi_bt_gatts_add_char(gatt_apcli.server.server_if,
                             gatt_apcli.service.handle,
                             gatt_apcli.chars[apcli_char_init_seq].uuid,
                             gatt_apcli.chars[apcli_char_init_seq].property,
                             gatt_apcli.chars[apcli_char_init_seq].permission))
    {
        BTMW_RPC_TEST_Loge("[GATTS APP] () a_mtkapi_bt_gatts_add_char(%d) NG\n", __func__);
        return ;
    }
}

VOID btmw_rpc_gatts_app_add_char_cbk(BT_GATTS_ADD_CHAR_RST_T *bt_gatts_add_char)
{
    if (gatt_apcli_use_sync_api)
        return ;
    if (bt_gatts_add_char->server_if != gatt_apcli.server.server_if ||
            bt_gatts_add_char->srvc_handle != gatt_apcli.service.handle)
        return ;
    gatt_apcli.chars[apcli_char_init_seq].handle = bt_gatts_add_char->char_handle;
    gatt_apcli.chars[apcli_char_init_seq].service_p = &gatt_apcli.service;
    BTMW_RPC_TEST_Logd("[GATTS APP] charactors uuid orig: %s\n",
                   gatt_apcli.chars[apcli_char_init_seq].uuid);
    if (gatt_apcli.chars[apcli_char_init_seq].desc_num > 0)
    {
        apcli_desc_init_seq = 0;
        if (a_mtkapi_bt_gatts_add_desc(gatt_apcli.server.server_if,
                                 gatt_apcli.service.handle,
                                 gatt_apcli.chars[apcli_char_init_seq].desc[apcli_desc_init_seq].uuid,
                                 gatt_apcli.chars[apcli_char_init_seq].desc[apcli_desc_init_seq].permission))
        {
            BTMW_RPC_TEST_Loge("[GATTS APP] %s() a_mtkapi_bt_gatts_add_desc(%d,%d) NG\n", __func__,
                           apcli_char_init_seq, apcli_desc_init_seq);
            return ;
        }
    }
    else if (gatt_apcli.char_num == apcli_char_init_seq)
    {
        //if(gatt_apcli.char_num == apcli_char_init_seq && gatt_apcli.chars[apcli_char_init_seq].desc_num == apcli_desc_init_seq)
        INT32 transport = 0;
        a_mtkapi_bt_gatts_start_service(gatt_apcli.server.server_if,
                                  gatt_apcli.service.handle,
                                  transport);
    }
}

VOID btmw_rpc_gatts_app_add_desc_cbk(BT_GATTS_ADD_DESCR_RST_T *bt_gatts_add_desc)
{
    if (gatt_apcli_use_sync_api)
        return ;
    if (bt_gatts_add_desc->server_if != gatt_apcli.server.server_if &&
            bt_gatts_add_desc->srvc_handle != gatt_apcli.service.handle)
        return ;
    gatt_apcli.chars[apcli_char_init_seq].desc[apcli_desc_init_seq].handle = bt_gatts_add_desc->descr_handle;
    gatt_apcli.chars[apcli_char_init_seq].desc[apcli_desc_init_seq].char_p = &gatt_apcli.chars[apcli_char_init_seq];
    BTMW_RPC_TEST_Logd("[GATTS APP] descriptor uuid orig(%d,%d): %s\n",
                   apcli_char_init_seq, apcli_desc_init_seq,
                   gatt_apcli.chars[apcli_char_init_seq].desc[apcli_desc_init_seq].uuid);
    if (gatt_apcli.chars[apcli_char_init_seq].desc_num > apcli_desc_init_seq + 1)
    {
        // add next desc
        apcli_desc_init_seq++;
        if (a_mtkapi_bt_gatts_add_desc(gatt_apcli.server.server_if,
                                 gatt_apcli.service.handle,
                                 gatt_apcli.chars[apcli_char_init_seq].desc[apcli_desc_init_seq].uuid,
                                 gatt_apcli.chars[apcli_char_init_seq].desc[apcli_desc_init_seq].permission))
        {
            BTMW_RPC_TEST_Loge("[GATTS APP] %s() a_mtkapi_bt_gatts_add_desc(%d,%d) NG\n",
                           __func__, apcli_char_init_seq, apcli_desc_init_seq);
            return ;
        }
    }
    else if (gatt_apcli.char_num > apcli_char_init_seq + 1)
    {
        // add next char
        apcli_char_init_seq++;
        if (a_mtkapi_bt_gatts_add_char(gatt_apcli.server.server_if,
                                 gatt_apcli.service.handle,
                                 gatt_apcli.chars[apcli_char_init_seq].uuid,
                                 gatt_apcli.chars[apcli_char_init_seq].property,
                                 gatt_apcli.chars[apcli_char_init_seq].permission))
        {
            BTMW_RPC_TEST_Loge("[GATTS APP] %s() a_mtkapi_bt_gatts_add_char(%d) NG\n",
                           __func__, apcli_char_init_seq);
            return ;
        }
    }
    else
    {
        //if(gatt_apcli.char_num == apcli_char_init_seq && gatt_apcli.chars[apcli_char_init_seq].desc_num == apcli_desc_init_seq)
        INT32 transport = 0;
        a_mtkapi_bt_gatts_start_service(gatt_apcli.server.server_if,
                                  gatt_apcli.service.handle,
                                  transport);
    }
}

VOID btmw_rpc_gatts_app_req_read_cbk(BT_GATTS_REQ_READ_RST_T *bt_gatts_read)
{
    //TODO use handle table link to the handle function point.
    // instead of linear search.
    CHAR *result = gatt_apcli_char_read(bt_gatts_read->attr_handle, bt_gatts_read->offset);
    BTMW_RPC_TEST_Logd("[GATTS APP] Register server callback : 1st char result = %s\n", result);
    if (!result)
        result = gatt_apcli_desc_read(bt_gatts_read->attr_handle, bt_gatts_read->offset);
    BTMW_RPC_TEST_Logd("[GATTS APP] Register server callback : 2nd desc result = %s\n", result);
    result = result ? result : " ";
    BTMW_RPC_TEST_Logd("[GATTS APP] Register server callback : final result = %s\n", result);
    INT32 length = strlen(result);
    a_mtkapi_bt_gatts_send_response(bt_gatts_read->conn_id,
                              bt_gatts_read->trans_id,
                              BT_SUCCESS,
                              bt_gatts_read->attr_handle,
                              result,
                              length,
                              0);
}

VOID btmw_rpc_gatts_app_req_write_cbk(BT_GATTS_REQ_WRITE_RST_T *bt_gatts_write)
{
    CHAR *result = gatt_apcli_char_write(bt_gatts_write->attr_handle,
                                         bt_gatts_write->offset,
                                         (CHAR *) bt_gatts_write->value,
                                         bt_gatts_write->length);
    if (!result)
        result = gatt_apcli_desc_write(bt_gatts_write->attr_handle, (CHAR *) bt_gatts_write->value, bt_gatts_write->length);
    result = result ? result : " ";
    INT32 length = strlen(result);
    if (bt_gatts_write->need_rsp)
    {
        a_mtkapi_bt_gatts_send_response(bt_gatts_write->conn_id,
                                  bt_gatts_write->trans_id,
                                  BT_SUCCESS,
                                  bt_gatts_write->attr_handle,
                                  result,
                                  length,
                                  0);
    }
}
#endif
