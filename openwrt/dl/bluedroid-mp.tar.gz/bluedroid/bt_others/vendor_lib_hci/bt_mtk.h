/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * MediaTek Inc. (C) 2014. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef _BT_MTK_H
#define _BT_MTK_H

#include "bt_hci_bdroid.h"
#include "bt_vendor_lib.h"
#include "os_dep.h"

#define HCI_CMD_MAX_SIZE        251
#define MAX(a, b) \
    (((a) > (b)) ? (a) : (b))

#define HCI_COMMAND_PKT 0x01
#define HCI_ACLDATA_PKT 0x02
#define HCI_SCODATA_PKT 0x03
#define HCI_EVENT_PKT   0x04
#define HCI_VENDOR_PKT  0xff

#define HCI_MIN_FRAME_SIZE 4
#define ACL_DATA_HEADER_SIZE 5
#define TX_DATA_FLAG 1
#define RX_DATA_FLAG 0

#ifdef MTK_MT7622
#define BT_FLASH_SUPPORT        1
#define BT_NVRAM_SUPPORT        0
#define BT_FW_CFG               1
#endif

#ifndef BT_FLASH_SUPPORT
#define BT_FLASH_SUPPORT        0
#endif
#ifndef BT_NVRAM_SUPPORT
#define BT_NVRAM_SUPPORT        0
#endif
#ifndef BT_FW_CFG
#define BT_FW_CFG               0
#endif

/***********   Structure Definitions   ***********/

typedef enum {
  BT_HCI_CMD = 0x01,
  BT_ACL,
  BT_SCO,
  BT_HCI_EVENT
} BT_HDR_T;

/***********   Function Declaration   ***********/
void set_callbacks(const bt_vendor_callbacks_t* p_cb);
void clean_callbacks(void);
int init_uart(void);
void close_uart(void);
int vendor_fw_cfg(void);
int vendor_sco_cfg(void);
void vendor_op_lmp_set_mode(void);
int mtk_prepare_off(void);
void clean_resource(void);
#if (defined(MTK_VENDOR_OPCODE) && (MTK_VENDOR_OPCODE == TRUE))
void mtk_enable_btsysclk(void *param);
void mtk_read_btsysclk(void *param);
#endif

#if BT_FW_CFG
#include "CFG_BT_File.h"
#include "CFG_BT_Default.h"
typedef enum {
  CMD_SUCCESS,
  CMD_FAIL,
  CMD_PENDING,
} HCI_CMD_STATUS_T;

typedef union {
    ap_nvram_btradio_struct fields;
    unsigned char raw[sizeof(ap_nvram_btradio_struct)];
} BT_NVRAM_DATA_T;

typedef BOOL (*HCI_CMD_FUNC_T) (HC_BT_HDR *);
typedef struct {
  HCI_CMD_FUNC_T command_func;
} HCI_SEQ_T;

typedef INT32 (*SETUP_UART_PARAM_T)(UINT32 u4Baud, UINT32 u4FlowControl);

typedef struct {
  UINT32 chip_id;
  BT_NVRAM_DATA_T bt_nvram;
  UINT32 bt_baud;
  UINT32 host_baud;
  UINT32 flow_ctrl;
  SETUP_UART_PARAM_T host_uart_cback;
  PUCHAR patch_ext_data;
  UINT32 patch_ext_len;
  UINT32 patch_ext_offset;
  PUCHAR patch_data;
  UINT32 patch_len;
  UINT32 patch_offset;
  HCI_SEQ_T *cur_script;
} BT_INIT_VAR_T;

/* Thread control block for Controller initialize */
typedef struct {
  pthread_t worker_thread;
  pthread_mutex_t mutex;
  pthread_mutexattr_t attr;
  pthread_cond_t cond;
  BOOL worker_thread_running;
} BT_INIT_CB_T;

BOOL BT_InitFW(VOID);
BOOL BT_InitSCO(VOID);
BOOL BT_DeinitDevice(VOID);
VOID BT_Cleanup(VOID);
int bt_read_fw_cfg(unsigned char *pucNvRamData);
#endif

#if BT_FLASH_SUPPORT
#include <sys/ioctl.h>
#define COMBO_BT_OFFSET     0
#define COMBO_BT_BDADDR_LEN 0x6
#define COMBO_BT_VOICE_LEN  0x2
#define COMBO_BT_CODEC_LEN  0x4
#define COMBO_BT_RADIO_LEN  0x2
#define COMBO_BT_SLEEP_LEN  0x7
#define COMBO_BT_OTHER_LEN  0x2
#define COMBO_BT_TX_PWR_LEN 0x6
#define COMBO_BT_COEX_LEN   0x6

#define COMBO_BT_BDADDR_OFFSET  (0x1a + COMBO_BT_OFFSET)
#define COMBO_BT_RADIO_OFFSET   (0x15e + COMBO_BT_OFFSET)
#define COMBO_BT_TX_PWR_OFFSET  (0x148 + COMBO_BT_OFFSET)

struct mtd_info_user {
    u_char type;
    u_int32_t flags;
    u_int32_t size;
    u_int32_t erasesize;
    u_int32_t oobblock;
    u_int32_t oobsize;
    u_int32_t ecctype;
    u_int32_t eccsize;
};

struct erase_info_user {
    u_int32_t start;
    u_int32_t length;
};

#define MEMGETINFO  _IOR('M', 1, struct mtd_info_user)
#define MEMERASE    _IOW('M', 2, struct erase_info_user)
#define min(a, b) ((a) < (b) ? (a) : (b))
#endif

#endif
