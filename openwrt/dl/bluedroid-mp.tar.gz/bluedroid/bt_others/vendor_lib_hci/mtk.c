/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * MediaTek Inc. (C) 2014. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sched.h>
#include <pthread.h>
#include <sys/syscall.h>
#include <sys/time.h>
#if defined(MTK_LINUX)
//#include "osi/include/properties.h"
#else
#include <cutils/properties.h>
#endif
#include "bt_mtk.h"


#if (defined(MTK_VENDOR_OPCODE) && (MTK_VENDOR_OPCODE == TRUE))
#include <sys/ioctl.h>

#define BTMTK_IOCTL_MAGIC 'k'

#define BTMTK_IOCTL_STEREO_GET_CLK _IOR(BTMTK_IOCTL_MAGIC, 1, void *)
#define BTMTK_IOCTL_STEREO_SET_PARA _IOW(BTMTK_IOCTL_MAGIC, 2, void *)
#endif

#define BTPROTO_HCI 1
#define HCI_CHANNEL_USER 1
#define HCI_BUF_SIZE (32 * 1024)
#define FD_NUM 3
#define CUST_BT_SERIAL_PORT "/dev/stpbt"
#define HW_ERR_CODE_BROKEN_PIPE 0xFF

#if __GLIBC__
pid_t gettid(void) { return syscall(SYS_gettid); }
#endif

/**************************************************************************
 *                  G L O B A L   V A R I A B L E S                       *
***************************************************************************/
bt_vendor_callbacks_t *bt_vnd_cbacks = NULL;
static int  bt_fd = -1;
static int tx_quit = 0;
static int rx_quit = 0;
static int sock_fd[FD_NUM] = {-1, -1, -1};
static pthread_t mtk_tx_thread = -1;
static pthread_t mtk_rx_thread = -1;
static pthread_mutex_t tx_mutex;
static pthread_mutex_t rx_mutex;

struct sockaddr_hci {
    sa_family_t    hci_family;
    unsigned short hci_dev;
    unsigned short hci_channel;
};

#define SHOW_RAW(len, buf) \
    do { \
        int i = 0; \
        while (i < len) { \
            LOG_ERR("%02X ", buf[i]); \
            i++; \
        } \
        LOG_ERR("\n"); \
    } while (0);

/**************************************************************************
 *              F U N C T I O N   D E C L A R A T I O N S                 *
***************************************************************************/

/**************************************************************************
 *                          F U N C T I O N S                             *
***************************************************************************/

static BOOL is_memzero(unsigned char *buf, int size)
{
    int i;
    for (i = 0; i < size; i++) {
        if (*(buf+i) != 0) return FALSE;
    }
    return TRUE;
}

/* Register callback functions to libbt-hci.so */
void set_callbacks(const bt_vendor_callbacks_t *p_cb)
{
    bt_vnd_cbacks = (bt_vendor_callbacks_t*)p_cb;
}

/* Cleanup callback functions previously registered */
void clean_callbacks(void)
{
    bt_vnd_cbacks = NULL;
}

static void mtk_set_tx_thread_quit(void)
{
    LOG_WAN("enter\n");
    pthread_mutex_lock(&tx_mutex);
    LOG_WAN("lock tx mutex, tx_quit = %d\n", tx_quit);
    tx_quit = 1;
    LOG_WAN("unlock tx mutex, tx_quit = %d\n", tx_quit);
    pthread_mutex_unlock(&tx_mutex);
    LOG_WAN("exit\n");
}
static int mtk_is_tx_thread_quit(void)
{
    int quit = 0;
    pthread_mutex_lock(&tx_mutex);
    quit = tx_quit;
    pthread_mutex_unlock(&tx_mutex);
    if (quit == 1) {
        LOG_WAN("quit(%d)\n", quit);
    }
    return quit;
}

static void mtk_set_rx_thread_quit(void)
{
    LOG_WAN("enter\n");
    pthread_mutex_lock(&rx_mutex);
    LOG_WAN("lock rx mutex, rx_quit = %d\n", rx_quit);
    rx_quit = 1;
    LOG_WAN("unlock rx mutex, rx_quit = %d\n", rx_quit);
    pthread_mutex_unlock(&rx_mutex);
    LOG_WAN("exit\n");
}
static int mtk_is_rx_thread_quit(void)
{
    int quit = 0;
    pthread_mutex_lock(&rx_mutex);
    quit = rx_quit;
    pthread_mutex_unlock(&rx_mutex);
    if (quit == 1) {
        LOG_WAN("quit(%d)\n", quit);
    }
    return quit;
}

static ssize_t mtk_read_data(int fd, uint8_t *buf, size_t size)
{
    ssize_t nRead = 0;

    if (fd < 0) {
        LOG_ERR("File descriptor in bad state\n");
        return -EIO;
    }

    if (!buf || !size) {
        LOG_ERR("Invalid argument buf:%p, size:%d\n", buf, (int)size);
        return -EINVAL;
    }

    //nRead = read(fd, buf, size);
    nRead = recv(fd, buf, size, 0);
    if (nRead <= 0) {
        if (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK) {
            LOG_WAN("%s(%d), nRead = %d\n", strerror(errno), errno, nRead);
            return 0;
        } else {
            LOG_ERR("%s(%d)\n", strerror(errno), errno);
            return -errno;
        }
    }
    //LOG_DBG("read data from fd: %d, nRead = %d\n", fd, nRead);
    //SHOW_RAW(nRead, buf);
    return nRead;
}

static ssize_t mtk_write_data(int fd, uint8_t *buf, size_t len)
{
    ssize_t ret = 0;
    size_t bytesToWrite = len;
    int ms_timeout = 1000;

    if (fd < 0) {
        LOG_ERR("File descriptor in bad state\n");
        return -EIO;
    }

    if (!buf || !len) {
        LOG_ERR("Invalid argument buf:%p, size:%d\n", buf, (int)len);
        return -EINVAL;
    }

    //LOG_WAN("write data to fd: %d, len = %d\n", fd, len);
    //SHOW_RAW(len, buf);
    while (bytesToWrite > 0) {
        //ret = write(fd, buf, bytesToWrite);
         ret = send(fd, buf, bytesToWrite, MSG_DONTWAIT);
        if (ret == -1) {
            if (errno != EAGAIN && errno != EWOULDBLOCK) {
                LOG_WAN("%s(%d)\n", strerror(errno), errno);
                return -1;
            }

            if (ms_timeout >= 100) {
                usleep(100 * 1000);
                ms_timeout -= 100;
                continue;
            }
            LOG_WAN("write timeout exceeded, sent %zu bytes", len - bytesToWrite);
            return -1;
        }
        bytesToWrite -= ret;
        buf += ret;
    }

    //LOG_WAN("write data actual len = %d\n", len - bytesToWrite);
    return (len - bytesToWrite);
}

static int mtk_unpack_and_write_host_data(int fd, uint8_t *buf, size_t read_len)
{
    uint16_t real_len = 0;
    ssize_t write_len = 0;
    int i = 0;

    if (fd < 0 || !buf) {
        LOG_ERR("Invalid argument buf:%p, fd :%d\n", buf, fd);
        return -EINVAL;
    }

    if (read_len < HCI_MIN_FRAME_SIZE) {
        LOG_ERR("Read data from host failed, read_len = %d\n", read_len);
        return -EINVAL;
    }

    if (buf[0] != HCI_COMMAND_PKT &&
        buf[0] != HCI_ACLDATA_PKT &&
        buf[0] != HCI_SCODATA_PKT) {
        LOG_ERR("pkt type is invalid, pkt type = %d, read_len = %d\n",
            buf[0], read_len);
        SHOW_RAW(read_len < 20 ? read_len : 20, buf);
        return -EINVAL;
    }
    /* maybe two or more acl packets in socket buffer,
       * the read_len will be larger than HCI_MAX_FRAME_SIZE,
       * we need to unpack the data from the buf
       */
    if (read_len > HCI_MAX_FRAME_SIZE) {
        LOG_WAN("buf len maybe include two or more packets leng, len = %d\n", read_len);
    }

    if (buf[0] == HCI_ACLDATA_PKT && read_len > ACL_DATA_HEADER_SIZE) {
        /* ACL data header: 0x02 xx xx xx xx, unpack data from the buf */
        real_len = buf[3] + ((buf[4] << 8) & 0xff00) + ACL_DATA_HEADER_SIZE;
    } else if (buf[0] == HCI_COMMAND_PKT) {
        /* HCI cmd header: 0x01 xx xx xx, unpack data from the buf */
        real_len = buf[3] + HCI_MIN_FRAME_SIZE;
    } else {
        LOG_ERR("pkt type or read_len is invalid, pkt type = %d, read_len = %d\n",
            buf[0], read_len);
        SHOW_RAW(read_len < 20 ? read_len : 20, buf);
        return -EINVAL;
    }

    i = 0;
    if (read_len >= real_len) {
        while (i < read_len) {
            write_len = mtk_write_data(fd, buf + i, real_len);
            if (write_len <= 0) {
                LOG_ERR("Write data to controller failed\n");
                return -EIO;
            }
            i +=  real_len;

            if (buf[i] == HCI_ACLDATA_PKT) {
                /* to avoid buf[i+4] to overflow*/
                if (i + ACL_DATA_HEADER_SIZE > read_len)
                    break;

                real_len = buf[i + 3] + ((buf[i + 4] << 8) & 0xff00) + ACL_DATA_HEADER_SIZE;
            } else if (buf[i] == HCI_COMMAND_PKT) {
                /* to avoid buf[i+3] to overflow*/
                if (i + HCI_MIN_FRAME_SIZE > read_len)
                    break;

                /* HCI cmd header: 0x01 xx xx xx, unpack data from the buf */
                real_len = buf[i + 3] + HCI_MIN_FRAME_SIZE;
            }
        }
    } else {
        LOG_ERR("read_len is invalid, read_len = %d, real_len = %d\n",
            read_len, real_len);
        return -EINVAL;
    }
    return 0;
}

static void mtk_close_sock_fd(void)
{
    if (bt_fd >= 0) {
        LOG_WAN("close bt_fd = %d!\n", bt_fd);
        close(bt_fd);
        bt_fd = -1;
        sock_fd[0] = -1;
    }

    if (sock_fd[1] >= 0) {
        LOG_WAN("close sock_fd[1] = %d!\n", sock_fd[1]);
        close(sock_fd[1]);
        sock_fd[1] = -1;
    }

    if (sock_fd[2] >= 0) {
        LOG_WAN("close sock_fd[2] = %d!\n", sock_fd[2]);
        close(sock_fd[2]);
        sock_fd[2] = -1;
    }
}

#if 0
static void mtk_process_trx_data(int read_fd, int write_fd, int *cont, int trx_flag)
{
    uint8_t buf[HCI_BUF_SIZE] = {0};
    ssize_t read_len = 0;
    ssize_t write_len = 0;
    int ret = 0;
    // Make watching thread RT.
    struct sched_param rt_params;
    int result;
    struct timeval tv;

    rt_params.sched_priority = 1;
    if (sched_setscheduler(gettid(), SCHED_FIFO, &rt_params)) {
        LOG_ERR("unable to set SCHED_FIFO for pid %d, tid %d, error %s\n",
          getpid(), gettid(), strerror(errno));
    }

    LOG_WAN("enter, read_fd = %d, write_fd = %d, cont = %d\n", read_fd, write_fd, *cont);

    while (*cont && read_fd >= 0 && write_fd >= 0) {
        fd_set read_fds;
        FD_ZERO(&read_fds);
        memset(buf, 0, sizeof(buf));

        if (read_fd >= 0)
            FD_SET(read_fd, &read_fds);

        tv.tv_sec = 0; /* SECOND */
        tv.tv_usec = 500000; /* USECOND */
        result = select(read_fd + 1, &read_fds, NULL, NULL, &tv);
        if (result == 0) {
            //LOG_WAN("select timeout\n");
            continue;
        }

        if (result < 0) {
            LOG_WAN("select failed %s(%d)\n", strerror(errno), errno);
            continue;
        }

        if (FD_ISSET(read_fd, &read_fds)) {
            read_len = mtk_read_data(read_fd, buf, HCI_BUF_SIZE);
            if (read_len <= 0) {
                LOG_ERR("Read data failed, read_len = %d\n", read_len);
                break;
            }

            if (trx_flag == TX_DATA_FLAG) {
                ret = mtk_unpack_and_write_host_data(write_fd, buf, read_len);
                if (ret < 0) {
                    LOG_ERR("Write data to controller failed\n");
                    break;
                }
            } else {
                write_len = mtk_write_data(write_fd, buf, read_len);
                if (write_len <= 0) {
                    LOG_ERR("Write data to host failed\n");
                    break;
                }
            }
        }
    }
}
#endif

static void mtk_vendor_lib_process_reset(void)
{
    LOG_WAN("Restarting BT process");
    usleep(10000); /* 10 milliseconds */
    /* Killing the process to force a restart as part of fault tolerance */
    kill(getpid(), SIGKILL);
}

void mtk_vendor_lib_send_hw_err_to_host(int write_fd)
{
    uint8_t hwerr_event[] = { 0x04, 0x10, 0x01, HW_ERR_CODE_BROKEN_PIPE };
    ssize_t write_len = 0;

    LOG_WAN("Send hw err to host");
    write_len = mtk_write_data(write_fd, hwerr_event, sizeof(hwerr_event));
    if (write_len <= 0)
        LOG_ERR("Write hw err to host failed, write_len = %d\n", write_len);
}

static void *mtk_vendor_lib_tx_thread_main(void *arg)
{
    int *fd = (int *)arg;
    uint8_t buf[HCI_BUF_SIZE] = {0};
    ssize_t read_len = 0;
    ssize_t write_len = 0;
    int ret = 0;
    // Make watching thread RT.
    struct sched_param rt_params;
    int result;
    struct timeval tv;

    rt_params.sched_priority = 1;
    if (sched_setscheduler(gettid(), SCHED_FIFO, &rt_params)) {
        LOG_ERR("unable to set SCHED_FIFO for pid %d, tid %lu, error %s\n",
          getpid(), pthread_self(), strerror(errno));
    }

    LOG_WAN("enter, fd[0] = %d, fd[1] = %d, fd[2] = %d, tx_quit = %d, tid %lu\n",
        fd[0], fd[1], fd[2], mtk_is_tx_thread_quit(), pthread_self());

     /* Process the data from BT host, BT host write to fd0, vendor lib read from  fd1, write to fd2 */
    while (!mtk_is_tx_thread_quit() && fd[1] >= 0 && fd[2] >= 0) {
        fd_set read_fds;
        FD_ZERO(&read_fds);
        memset(buf, 0, sizeof(buf));

        if (fd[1] >= 0)
            FD_SET(fd[1], &read_fds);

        tv.tv_sec = 0; /* SECOND */
        tv.tv_usec = 200000; /* USECOND */
        result = select(fd[1] + 1, &read_fds, NULL, NULL, &tv);
        if (result == 0) {
            //LOG_WAN("select timeout\n");
            continue;
        }

        if (result < 0) {
            LOG_WAN("select failed %s(%d)\n", strerror(errno), errno);
            continue;
        }

        if (FD_ISSET(fd[1], &read_fds)) {
            read_len = mtk_read_data(fd[1], buf, HCI_BUF_SIZE);
            if (read_len <= 0) {
                LOG_ERR("Read data from host failed, read_len = %d\n", read_len);
                break;
            }

            ret = mtk_unpack_and_write_host_data(fd[2], buf, read_len);
            if (ret < 0) {
                LOG_ERR("Write data to controller failed\n");
                break;
            }
        }
    }

    //mtk_process_trx_data(fd[1], fd[2], &tx_cont, TX_DATA_FLAG);

    mtk_tx_thread = -1;
    LOG_WAN("exit\n");
    return NULL;
}

static void *mtk_vendor_lib_rx_thread_main(void *arg)
{
    int *fd = (int *)arg;
    uint8_t buf[HCI_BUF_SIZE] = {0};
    ssize_t read_len = 0;
    ssize_t write_len = 0;
    // Make watching thread RT.
    struct sched_param rt_params;
    int result;
    struct timeval tv;

    rt_params.sched_priority = 1;
    if (sched_setscheduler(gettid(), SCHED_FIFO, &rt_params)) {
        LOG_ERR("unable to set SCHED_FIFO for pid %d, tid %d, error %s\n",
          getpid(), pthread_self(), strerror(errno));
    }

    LOG_WAN("enter, fd[0] = %d, fd[1] = %d, fd[2] = %d, rx_quit = %d, tid %lu\n",
        fd[0], fd[1], fd[2], mtk_is_rx_thread_quit(), pthread_self());

    /* Process the data from BT controller, vendor lib read from fd2, write to fd1, BT host read from fd0 */
    while (!mtk_is_rx_thread_quit() && fd[1] >= 0 && fd[2] >= 0) {
        fd_set read_fds;
        FD_ZERO(&read_fds);
        memset(buf, 0, sizeof(buf));

        if (fd[2] >= 0)
            FD_SET(fd[2], &read_fds);

        tv.tv_sec = 0; /* SECOND */
        tv.tv_usec = 200000; /* USECOND */
        //LOG_WAN("select timeout, tv.tv_sec = %ld, tv.tv_usec = %ld\n",
        //    tv.tv_sec, tv.tv_usec);
        result = select(fd[2] + 1, &read_fds, NULL, NULL, &tv);
        if (result == 0) {
            //LOG_WAN("select timeout\n");
            continue;
        }

        if (result < 0) {
            LOG_WAN("select failed %s(%d)\n", strerror(errno), errno);
            continue;
        }

        if (FD_ISSET(fd[2], &read_fds)) {
            read_len = mtk_read_data(fd[2], buf, HCI_BUF_SIZE);
            if (read_len == 0) {
                LOG_WAN("read_len = %d\n", read_len);
                continue;
            } else if (read_len < 0) {
                LOG_ERR("Read data from controller failed, read_len:%d\n", read_len);
                if (read_len == -EPIPE) {
                    //mtk_vendor_lib_process_reset();
                    mtk_vendor_lib_send_hw_err_to_host(fd[1]);
                }
                break;
            }
            write_len = mtk_write_data(fd[1], buf, read_len);
            if (write_len <= 0) {
                LOG_ERR("Write data to host failed\n");
                break;
            }
        }
    }

    //mtk_process_trx_data(fd[2], fd[1], &rx_cont, RX_DATA_FLAG);

    mtk_rx_thread = -1;
    LOG_WAN("exit\n");
    return NULL;
}

int mtk_vendor_lib_setsockopt(void)
{
    struct timeval tv;
    int get_size = 0;
    socklen_t sock_len = sizeof(get_size);
    int i = 0;
    int ret = -1;

    tv.tv_sec = 1; /* SECOND */
    tv.tv_usec = 0; /* USECOND */

    for (i = 0; i < FD_NUM; i++) {

        /*getsockopt socket buffer size*/
        ret = getsockopt(sock_fd[i], SOL_SOCKET, SO_RCVBUF, (char*)&get_size, &sock_len);
        if (ret < 0) {
            LOG_ERR("setsockopt sock_fd[%d] SO_RCVBUF failed (%s)\n", i, strerror(errno));
            return ret;
        }
        LOG_WAN("getsockopt sock_fd[%d] SO_RCVBUF get_size (%d)\n", i, get_size / 1024);

        ret = getsockopt(sock_fd[i], SOL_SOCKET, SO_SNDBUF, (char*)&get_size, &sock_len);
        if (ret < 0) {
            LOG_ERR("setsockopt sock_fd[%d] SO_SNDBUF failed (%s)\n", i, strerror(errno));
            return ret;
        }
        LOG_WAN("getsockopt sock_fd[%d] SO_SNDBUF get_size (%d)\n", i, get_size / 1024);

        ret = setsockopt(sock_fd[i], SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
        if (ret < 0) {
            LOG_ERR("setsockopt sock_fd[%d] SO_RCVTIMEO faild (%s)\n", i, strerror(errno));
            return ret;
        }

        ret = setsockopt(sock_fd[i], SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
        if (ret < 0) {
            LOG_ERR("setsockopt sock_fd[%d] SO_SNDTIMEO failed (%s)\n", i, strerror(errno));
            return ret;
        }
    }

    return ret;
}

/* Initialize UART port */
int init_uart(void)
{
    int retry = 50;
    int ret = -1;
    struct sockaddr_hci addr;
    struct stat s;
    pthread_attr_t attr;

    LOG_TRC();

    if (bt_fd >= 0) {
        LOG_WAN("Previous serial port is not closed\n");
        close_uart();
    }

    if (stat(CUST_BT_SERIAL_PORT, &s) == 0) {
        while(1) {
            bt_fd = open(CUST_BT_SERIAL_PORT, O_RDWR | O_NOCTTY | O_NONBLOCK | O_CLOEXEC);
            if (bt_fd < 0) {
                LOG_WAN("Can't open serial port, Retry\n");
                usleep(200000);/*200ms*/
                if (retry <= 0)
                    break;
                retry--;
            } else
                break;
        }

        if (bt_fd < 0) {
            LOG_ERR("Can't open serial port stpbt, errno = %d\n", errno);
            return -1;
        }
    } else {
        /*create socketpair*/
        ret = socketpair(AF_LOCAL, SOCK_STREAM, 0, sock_fd);
        if (ret == -1) {
            LOG_ERR("create socketpair fail: %s(%d)\n", strerror(errno), errno);
            return ret;
        }

        bt_fd = sock_fd[0];
        rx_quit = 0;
        tx_quit = 0;
        LOG_WAN("create socket start, fd[0] = %d, fd[1] = %d, fd[2] = %d\n",
                bt_fd, sock_fd[1], sock_fd[2]);

        /* create socket to comunicate with kernel hci driver*/
        sock_fd[FD_NUM - 1] = socket(AF_BLUETOOTH, SOCK_RAW, BTPROTO_HCI);
        if (sock_fd[FD_NUM - 1] < 0) {
            LOG_ERR("socket create error : %s(%d)\n", strerror(errno), errno);
            mtk_close_sock_fd();
            return -1;
        } else {
            memset(&addr, 0, sizeof(addr));
            addr.hci_family = AF_BLUETOOTH;
            addr.hci_dev = 0;
            addr.hci_channel = HCI_CHANNEL_USER;
            while (1) {
                if(bind(sock_fd[FD_NUM - 1], (struct sockaddr *) &addr, sizeof(addr)) < 0) {
                    if (errno == ENODEV) {
                        LOG_WAN("bind error %s %d, retry\n", strerror(errno), errno);
                        usleep(200000);/*200ms*/
                        if (retry <= 0)
                            goto err;
                        retry--;
                        continue;
                    }
 err:
                    LOG_ERR("bind error %s %d\n", strerror(errno), errno);
                    mtk_close_sock_fd();
                    return -1;
                } else
                    break;
            }
            LOG_WAN("create socket end, fd[0] = %d, fd[1] = %d, fd[2] = %d\n",
                sock_fd[0], sock_fd[1], sock_fd[2]);

            ret = mtk_vendor_lib_setsockopt();
            if (ret < 0) {
                LOG_ERR("mtk_vendor_lib_setsockopt error, ret(%d)\n", ret);
                mtk_close_sock_fd();
                return -1;
            }
        }

        pthread_mutex_init(&tx_mutex, NULL);
        pthread_mutex_init(&rx_mutex, NULL);

        /* create thread to read/write from/to sockpair*/
        pthread_attr_init(&attr);
        pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
        ret = pthread_create(&mtk_tx_thread, &attr, mtk_vendor_lib_tx_thread_main, (void *)sock_fd);
        if (ret != 0) {
            LOG_ERR("pthread_create tx thread fail : %s\n", strerror(errno));
            mtk_close_sock_fd();
            return -1;
        }
        LOG_WAN("create mtk_vendor_lib_tx_thread_main success!\n");

        ret = pthread_create(&mtk_rx_thread, &attr, mtk_vendor_lib_rx_thread_main, (void *)sock_fd);
        if (ret != 0) {
            LOG_ERR("pthread_create rx thread fail : %s\n", strerror(errno));
            mtk_close_sock_fd();
            return -1;
        }
        LOG_WAN("create mtk_vendor_lib_rx_thread_main success!\n");
    }

    return bt_fd;
}

/* Close UART port previously opened */
void close_uart(void)
{
    LOG_TRC();
    mtk_set_tx_thread_quit();
    mtk_set_rx_thread_quit();

    while (1) {
        if (mtk_tx_thread != -1 || mtk_rx_thread != -1) {
            LOG_WAN("wait tx/rx thread exit, mtk_tx_thread = %ld, mtk_rx_thread = %ld!\n",
                mtk_tx_thread, mtk_rx_thread);
            usleep(200000);
        }
        else
            break;
    }

    mtk_close_sock_fd();
    pthread_mutex_destroy(&tx_mutex);
    pthread_mutex_destroy(&rx_mutex);
}

/* MTK specific chip initialize process */
int vendor_fw_cfg(void)
{
#if BT_FW_CFG
    return BT_InitFW();
#else
    LOG_TRC();
    if (bt_vnd_cbacks) {
        LOG_ERR("bt_vnd_cbacks fwcfg_cb done\n");
        bt_vnd_cbacks->fwcfg_cb(BT_VND_OP_RESULT_SUCCESS);
    }
    return 0;
#endif
}

/* MTK specific SCO/PCM configuration */
int vendor_sco_cfg(void)
{
#if BT_FW_CFG
    return (BT_InitSCO() == TRUE ? 0 : -1);
#else
    LOG_TRC();
    if (bt_vnd_cbacks) {
        LOG_ERR("bt_vnd_cbacks scocfg_cb done\n");
        bt_vnd_cbacks->scocfg_cb(BT_VND_OP_RESULT_SUCCESS);
    }
    return 0;
#endif
}

void vendor_op_lmp_set_mode(void)
{
    if (bt_vnd_cbacks) {
        bt_vnd_cbacks->lpm_cb(BT_VND_OP_RESULT_SUCCESS);
    }
}

/* MTK specific deinitialize process */
int mtk_prepare_off(void)
{
    /*
    * On KK, BlueDroid adds BT_VND_OP_EPILOG procedure when BT disable:
    *   - 1. BT_VND_OP_EPILOG;
    *   - 2. In vendor epilog_cb, send EXIT event to bt_hc_worker_thread;
    *   - 3. Wait for bt_hc_worker_thread exit;
    *   - 4. userial close;
    *   - 5. vendor cleanup;
    *   - 6. Set power off.
    * On L, the disable flow is modified as below:
    *   - 1. userial Rx thread exit;
    *   - 2. BT_VND_OP_EPILOG;
    *   - 3. Write reactor->event_fd to trigger bt_hc_worker_thread exit
    *        (not wait to vendor epilog_cb and do nothing in epilog_cb);
    *   - 4. Wait for bt_hc_worker_thread exit;
    *   - 5. userial close;
    *   - 6. Set power off;
    *   - 7. vendor cleanup.
    *
    * It seems BlueDroid does not expect Tx/Rx interaction with chip during
    * BT_VND_OP_EPILOG procedure, and also does not need to do it in a new
    * thread context (NE may occur in __pthread_start if bt_hc_worker_thread
    * has already exited).
    * So BT_VND_OP_EPILOG procedure may be not for chip deinitialization,
    * do nothing, just notify success.
    *
    * [FIXME!!]How to do if chip deinit is needed?
    */
    //return (BT_DeinitDevice() == TRUE ? 0 : -1);
    if (bt_vnd_cbacks) {
        bt_vnd_cbacks->epilog_cb(BT_VND_OP_RESULT_SUCCESS);
    }
    return 0;
}

/* Cleanup driver resources, e.g thread exit */
void clean_resource(void)
{
    BT_Cleanup();
}

#if (defined(MTK_VENDOR_OPCODE) && (MTK_VENDOR_OPCODE == TRUE))
void mtk_enable_btsysclk(void *param)
{
    if (ioctl(bt_fd, BTMTK_IOCTL_STEREO_SET_PARA, param) < 0) {
        LOG_ERR("Set mtk_enable_btsysclk error, %s, errno[%d]\n", strerror(errno), errno);
        return;
    }
}

void mtk_read_btsysclk(void *param)
{
    if (ioctl(bt_fd, BTMTK_IOCTL_STEREO_GET_CLK, param) < 0) {
        LOG_ERR("Set mtk_read_btsysclk error, %s, errno[%d]\n", strerror(errno), errno);
        return;
    }
}
#endif

