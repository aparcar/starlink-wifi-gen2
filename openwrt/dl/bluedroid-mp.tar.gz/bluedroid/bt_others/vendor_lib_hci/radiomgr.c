/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * MediaTek Inc. (C) 2014. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdlib.h>
#include <pthread.h>
#include <signal.h>
#include <string.h>
#include <stdio.h>
#include "bt_mtk.h"

#if BT_FW_CFG
/**************************************************************************
 *                  G L O B A L   V A R I A B L E S                       *
***************************************************************************/

extern BT_INIT_VAR_T btinit[1];
extern BT_INIT_CB_T btinit_ctrl;

/**************************************************************************
 *                          F U N C T I O N S                             *
***************************************************************************/

extern VOID *GORM_FW_Init_Thread(VOID *ptr);
extern VOID *GORM_SCO_Init_Thread(VOID *ptr);
extern VOID thread_exit(INT32 signo);

static int bt_get_combo_id(unsigned int *pChipId)
{
#ifdef MTK_MT7622
    *pChipId = 0x7622;
#endif
#ifdef MTK_MT7628
    *pChipId = 0x7628;
#endif

    LOG_DBG("Combo chip id %x\n", *pChipId);
    return 0;
}

BOOL BT_InitDevice(
    UINT32  chipId,
    PUCHAR  pucNvRamData,
    UINT32  u4Baud,
    UINT32  u4HostBaud,
    UINT32  u4FlowControl,
    SETUP_UART_PARAM_T setup_uart_param
    )
{
    LOG_DBG("BT_InitDevice\n");

    memset(btinit, 0, sizeof(BT_INIT_VAR_T));
    btinit_ctrl.worker_thread_running = FALSE;

    btinit->chip_id = chipId;
    /* Copy configuration data */
    memcpy(btinit->bt_nvram.raw, pucNvRamData, sizeof(ap_nvram_btradio_struct));
    /* Save init variables, which are used on standalone chip */
    btinit->bt_baud = u4Baud;
    btinit->host_baud = u4HostBaud;
    btinit->flow_ctrl = u4FlowControl;
    btinit->host_uart_cback = setup_uart_param;

    if (SIG_ERR == signal(SIGRTMIN, thread_exit)) {
        LOG_ERR("Register signal handler fails errno(%d)\n", errno);
    }

    pthread_attr_t attr;
    int i4_ret = 0;
    i4_ret = pthread_attr_init(&attr);
    if (0 != i4_ret)
    {
        LOG_ERR("thread attr init fail\n");
        return FALSE;
    }

    i4_ret = pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    if (0 != i4_ret)
    {
        pthread_attr_destroy(&attr);
        LOG_ERR("thread pthread_attr_setdetachstate fail\n");
        return FALSE;
    }
    if (pthread_create(&btinit_ctrl.worker_thread, &attr, \
          GORM_FW_Init_Thread, NULL) != 0) {
        pthread_attr_destroy(&attr);
        LOG_ERR("Create FW init thread fails\n");
        return FALSE;
    }
    else {
        pthread_attr_destroy(&attr);
        btinit_ctrl.worker_thread_running = TRUE;
        return TRUE;
    }
}

BOOL BT_InitFW(VOID)
{
    unsigned int chipId = 0;
    unsigned char ucNvRamData[sizeof(ap_nvram_btradio_struct)] = {0};
    unsigned int speed = 0;
    unsigned int flow_control = 0;
    SETUP_UART_PARAM_T uart_setup_callback = NULL;
    int ret = 0;

    LOG_TRC();

    /* Get combo chip id */
    if (bt_get_combo_id(&chipId) < 0) {
        LOG_ERR("Get combo chip id fails\n");
        return -1;
    }

    /* Read flash data */
    ret = bt_read_fw_cfg(ucNvRamData);
    if ((ret < 0) ||
          is_memzero(ucNvRamData, sizeof(ap_nvram_btradio_struct))) {
        LOG_WAN("Read NVRAM data fails or NVRAM data all zero!!\n");
        LOG_WAN("Use %x default value\n", chipId);
        switch (chipId) {
#ifdef MTK_MT7628
            case 0x7628:
                memcpy(ucNvRamData, &stBtDefault_7628, sizeof(ap_nvram_btradio_struct));
            break;
#endif
#ifdef MTK_MT7622
            case 0x7622:
                memcpy(ucNvRamData, &stBtDefault_7622, sizeof(ap_nvram_btradio_struct));
            break;
#endif

            default:
                LOG_ERR("Unknown combo chip id: %04x\n", chipId);
                return -1;
        }
    }

    LOG_WAN("[BDAddr %02x-%02x-%02x-%02x-%02x-%02x][Voice %02x %02x][Codec %02x %02x %02x %02x]" \
            "[Radio %02x %02x][Sleep %02x %02x %02x %02x %02x %02x %02x][BtFTR %02x %02x]" \
            "[TxPWOffset %02x %02x %02x %02x %02x %02x][CoexAdjust %02x %02x %02x %02x %02x %02x] \n",
            ucNvRamData[0], ucNvRamData[1], ucNvRamData[2], ucNvRamData[3], ucNvRamData[4], ucNvRamData[5],
            ucNvRamData[6], ucNvRamData[7],
            ucNvRamData[8], ucNvRamData[9], ucNvRamData[10], ucNvRamData[11],
            ucNvRamData[12], ucNvRamData[13],
            ucNvRamData[14], ucNvRamData[15], ucNvRamData[16], ucNvRamData[17], ucNvRamData[18], ucNvRamData[19], ucNvRamData[20],
            ucNvRamData[21], ucNvRamData[22],
            ucNvRamData[23], ucNvRamData[24], ucNvRamData[25], ucNvRamData[26], ucNvRamData[27], ucNvRamData[28],
            ucNvRamData[29], ucNvRamData[30], ucNvRamData[31], ucNvRamData[32], ucNvRamData[33], ucNvRamData[34]);

    return (BT_InitDevice(
              chipId,
              ucNvRamData,
              speed,
              speed,
              flow_control,
              uart_setup_callback) == TRUE ? 0 : -1);
}

BOOL BT_InitSCO(VOID)
{
    LOG_DBG("BT_InitSCO\n");

    pthread_attr_t attr;
    int i4_ret = 0;
    i4_ret = pthread_attr_init(&attr);
    if (0 != i4_ret)
    {
        LOG_ERR("thread attr init fail\n");
        return FALSE;
    }

    i4_ret = pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    if (0 != i4_ret)
    {
        pthread_attr_destroy(&attr);
        LOG_ERR("thread pthread_attr_setdetachstate fail\n");
        return FALSE;
    }
    if (pthread_create(&btinit_ctrl.worker_thread, &attr, \
          GORM_SCO_Init_Thread, NULL) != 0) {
        pthread_attr_destroy(&attr);
        LOG_ERR("Create SCO init thread fails\n");
        return FALSE;
    }
    else {
         pthread_attr_destroy(&attr);
        btinit_ctrl.worker_thread_running = TRUE;
        return TRUE;
    }
}

BOOL BT_DeinitDevice(VOID)
{
    LOG_DBG("BT_DeinitDevice\n");
    /* Do nothing on combo chip */
    return TRUE;
}
#endif

VOID BT_Cleanup(VOID)
{
#if BT_FW_CFG
    /* Cancel any remaining running thread */
    if (btinit_ctrl.worker_thread_running) {
        pthread_kill(btinit_ctrl.worker_thread, SIGRTMIN);
        /* Wait until thread exit */
        //pthread_join(btinit_ctrl.worker_thread, NULL);
        btinit_ctrl.worker_thread_running = FALSE;
    }
#endif
    if (SIG_ERR == signal(SIGRTMIN, SIG_DFL)) {
        LOG_ERR("Restore signal handler fails errno(%d)\n", errno);
    }
    return;
}

