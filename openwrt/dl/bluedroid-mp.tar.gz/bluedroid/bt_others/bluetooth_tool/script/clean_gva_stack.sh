#!/bin/bash

cd ${Bluetooth_Tool_Dir}
rm -rf gva_core

cd ${Gva_Bluetooth_Stack_Dir}
rm -rf out
