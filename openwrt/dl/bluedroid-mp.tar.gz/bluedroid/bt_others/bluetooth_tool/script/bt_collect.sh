##############################################################################################
if [ "$#" -eq "1" ]; then
  Platform=$1
  echo "Platform is $Platform"
fi
if [ $Platform = "MT7622" ]; then
  BT_STRIP=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-strip
elif [ $Platform = "MT7628" ]; then
  BT_STRIP=/opt/buildroot-gcc492_mips_glibc/usr/bin/mipsel-linux-strip
  BT_FIRMWARE_PATH=$(pwd)/../../../../../linux-3.10.14.x/drivers/bluetooth/mt76x2
else
  BT_STRIP=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-strip
fi
if [ ! $Script_Dir ]; then
  Script_Dir=$(pwd)
  echo $Script_Dir
  if [[ $(pwd) =~ "script/common" ]]; then
    Bluetooth_Tool_Dir=${Script_Dir}/../..
  else
    Bluetooth_Tool_Dir=${Script_Dir}/..
  fi
fi
if [ ! $Bluetooth_Prebuilts_Dir ]; then
  Bluetooth_Prebuilts_Dir=${Bluetooth_Tool_Dir}/prebuilts
fi
if [ ! $Bluedroid_Libs_Path ]; then
  Bluedroid_Libs_Path=${Bluetooth_Tool_Dir}/prebuilts/lib
fi

#system library file path:libbluetooth.default.so...
if [ ! $Platform_Libs_Path ]; then
  Platform_Libs_Path=${Bluetooth_Tool_Dir}/../../../lib
fi

#for romfs
if [ ! $Romfs ]; then
  Romfs=${Bluetooth_Tool_Dir}/../../../../romfs
fi
if [ $Platform = "MT7628" ]; then
  if [ ! -d ${Romfs}/lib/firmware ]; then
      mkdir -p ${Romfs}/lib/firmware
  fi
fi

##############################################################################################
echo "start romfs bluetooth lib"
$BT_STRIP ${Bluedroid_Libs_Path}/libbluetooth.default.so
$BT_STRIP ${Bluedroid_Libs_Path}/libaudio.a2dp.default.so
$BT_STRIP ${Bluedroid_Libs_Path}/libbt-mw.so
$BT_STRIP ${Bluedroid_Libs_Path}/libbt-vendor.so
install -m 644 $Bluedroid_Libs_Path/libbluetooth.default.so ${Romfs}/lib
install -m 644 $Bluedroid_Libs_Path/libaudio.a2dp.default.so ${Romfs}/lib
install -m 644 $Bluedroid_Libs_Path/libbt-mw.so ${Romfs}/lib
install -m 644 $Bluedroid_Libs_Path/libbt-vendor.so ${Romfs}/lib
install -m 644 $Bluetooth_Prebuilts_Dir/conf/bt_stack.conf ${Romfs}/etc_ro/bluedroid
install -m 644 $Bluetooth_Prebuilts_Dir/conf/bt_did.conf ${Romfs}/etc_ro/bluedroid
install -m 755 $Bluetooth_Prebuilts_Dir/bin/btmw-test ${Romfs}/bin
install -m 755 $Bluetooth_Prebuilts_Dir/bin/picus ${Romfs}/bin
install -m 755 $Bluetooth_Prebuilts_Dir/bin/boots ${Romfs}/bin
install -m 755 $Bluetooth_Prebuilts_Dir/bin/boots_srv ${Romfs}/bin
if [ $Platform = "MT7628" ]; then
  install -m 644 $BT_FIRMWARE_PATH/mt7662t_firmware_e1.bin ${Romfs}/lib/firmware
  install -m 644 $BT_FIRMWARE_PATH/mt7662t_patch_e1_hdr.bin ${Romfs}/lib/firmware
fi
