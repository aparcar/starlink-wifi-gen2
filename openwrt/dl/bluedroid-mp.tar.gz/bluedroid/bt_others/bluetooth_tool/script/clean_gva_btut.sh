#!/bin/bash

cd ${Bluetooth_Tool_Dir}/gva_btut
rm -rf out



