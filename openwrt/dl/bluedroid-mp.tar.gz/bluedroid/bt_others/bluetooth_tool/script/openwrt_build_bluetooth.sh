#!/bin/bash

export Script_Dir=$(pwd)
export Bluetooth_Tool_Dir=${Script_Dir}/../
echo "Script_Dir:${Script_Dir}"
echo "Bluetooth_Tool_Dir:${Bluetooth_Tool_Dir}"

################################ get input parameter ################################

if [ $1 ]; then
    PLATFORM=$1
    echo "PLATFORM is $PLATFORM"
else
    echo "should input PLATFORM"
    exit 1
fi
if [ $2 ]; then
    typeset -l MTK_BT_CHIP_ID
    export MTK_BT_CHIP_ID=$2
    echo "connectivity chip id is $MTK_BT_CHIP_ID"
else
    export MTK_BT_CHIP_ID=mt7622
fi
if [ $3 ]; then
    export OPENWRT=$3
    echo "is OPENWRT $OPENWRT"
fi
if [ $4 ]; then
    export param_CC=$4
    echo "CC is $param_CC"
fi
if [ $5 ]; then
    export param_CXX=$5
    echo "CXX is $param_CXX"
fi
if [ $6 ]; then
    export param_STRIP=$6
    echo "STRIP is $param_STRIP"
fi

if [ $OPENWRT = "yes" ]; then
################################ for LEDE case ################################
    echo ${Script_Dir%/build_dir*}
    lede_root=${Script_Dir%/build_dir*}
    echo "PLATFORM is $PLATFORM"
    echo "param_CC is $param_CC"
    echo "param_CXX is $param_CXX"
    echo "param_STRIP is $param_STRIP"
    echo "lede_root is $lede_root"
    if [ $param_CC = "aarch64-openwrt-linux-gnu-gcc" ]; then
        tmp_CC=$lede_root/staging_dir/toolchain-aarch64_cortex-a53+neon-vfpv4_gcc-5.4.0_glibc-2.24/bin/$param_CC
        tmp_CXX=$lede_root/staging_dir/toolchain-aarch64_cortex-a53+neon-vfpv4_gcc-5.4.0_glibc-2.24/bin/$param_CXX
        tmp_STRIP=$lede_root/staging_dir/toolchain-aarch64_cortex-a53+neon-vfpv4_gcc-5.4.0_glibc-2.24/bin/$param_STRIP
    elif [ $PLATFORM = "MT7628" ]; then
        tmp_CC=/opt/buildroot-gcc492_mips_glibc/usr/bin/mipsel-linux-gcc
        tmp_CXX=/opt/buildroot-gcc492_mips_glibc/usr/bin/mipsel-linux-g++
        tmp_STRIP=/opt/buildroot-gcc492_mips_glibc/usr/bin/mipsel-linux-strip

    elif [ $PLATFORM = "MT7622" ]; then
        tmp_CC=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-gcc
        tmp_CXX=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-g++
        tmp_STRIP=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-strip
    else
        tmp_CC=$param_CC
        tmp_CXX=$param_CXX
        tmp_STRIP=$param_STRIP
    fi
#project related path, integrator should care these path
    #BT_Tmp_Path is used for temporay path like as /tmp
    export BT_Tmp_Path=/tmp
    #BT_Misc_Path is used for misc path like as /misc
    export BT_Misc_Path=/etc
    #BT_Misc_Path is used for etc path like as /etc
    export BT_Etc_Path=/data/etc
else
################################ for lsdk case ################################
    if [ $PLATFORM = "MT7622" ]; then
        tmp_CC=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-gcc
        tmp_CXX=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-g++
        tmp_STRIP=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-strip
    elif [ $PLATFORM = "MT7628" ]; then
        tmp_CC=/opt/buildroot-gcc492_mips_glibc/usr/bin/mipsel-linux-gcc
        tmp_CXX=/opt/buildroot-gcc492_mips_glibc/usr/bin/mipsel-linux-g++
        tmp_STRIP=/opt/buildroot-gcc492_mips_glibc/usr/bin/mipsel-linux-strip
    else
        tmp_CC=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-gcc
        tmp_CXX=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-g++
        tmp_STRIP=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-strip
    fi
#project related path, integrator should care these path
    #BT_Tmp_Path is used for temporay path like as /tmp
    export BT_Tmp_Path=/tmp
    #BT_Misc_Path is used for misc path like as /misc
    export BT_Misc_Path=/etc
    #BT_Misc_Path is used for etc path like as /etc
    export BT_Etc_Path=/data/etc
fi

export CC=$tmp_CC
export CXX=$tmp_CXX
export STRIP=$tmp_STRIP
export BT_GET_CROSS_COMPILE="yes"
echo "CC is $CC"

export SUPPORT_AAC="no"
export SUPPORT_SPP="no"
export SUPPORT_HIDH="no"
export SUPPORT_HIDD="no"
export SUPPORT_GATT="yes"
export SUPPORT_AVRCP="no"
export SUPPORT_A2DP_SRC="no"
export SUPPORT_A2DP_ADEV="no"
export SUPPORT_A2DP_SINK="no"
export SUPPORT_HFP_CLIENT="no"
export SUPPORT_BT_WIFI_RATIO_SETTING="no"
export SUPPORT_DISPATCH_A2DP_WITH_PLAYBACK="yes"
export SUPPORT_BLE_MESH="no"
export SUPPORT_BLE_MESH_HEARTBEAT="no"

#1st phase:generate bluetooth vendor environment: lib and boots, picus common tools(vendor lib, tools)
FOR_BT_VENDOR="yes"
echo "Bluetooth_Tool_Dir:${Bluetooth_Tool_Dir}"
############ need set boots & picus path different with trunk ############

#export Bluetooth_Prebuilts_Dir=${Bluetooth_Tool_Dir}/prebuilts
#export Bluetooth_Vendor_Prebuilts_Dir=${Bluetooth_Tool_Dir}/prebuilts
export Bluetooth_Boots_Dir=${Bluetooth_Tool_Dir}/boots
export Bluetooth_Picus_Dir=${Bluetooth_Tool_Dir}/picus

/bin/bash generate_environment.sh ${MTK_BT_CHIP_ID} ${FOR_BT_VENDOR}

if [ ! $VENDOR_BT_SET_ENVIRONMENT ]; then
    export VENDOR_BT_SET_ENVIRONMENT="yes"
    source ./vendor_set_environment.sh
fi

#2nd phase:generate mw&stack environment: all other bluetooth related library and binary(mw, stack)
FOR_BT_VENDOR="no"
/bin/bash generate_environment.sh ${MTK_BT_CHIP_ID} ${FOR_BT_VENDOR}

if [ ! $BT_SET_ENVIRONMENT ]; then
    export BT_SET_ENVIRONMENT="yes"
    source ./set_environment.sh
fi

#clean build
echo "start clean bluetooth vendor_lib"
/bin/bash clean_bluetooth_vendor.sh
#echo "start clean bluetooth mw&stack"
#/bin/bash clean_all_no_rpc.sh

echo "start clean bluetooth mw&stack"
/bin/bash clean_all_rpc.sh

#start build
echo "start build bluetooth vendor_lib"
/bin/bash build_bluetooth_vendor.sh

#echo "start build build_all_no_rpc"
#/bin/bash build_all_rpc.sh
echo "start build build_all_rpc"
/bin/bash build_all_rpc.sh
echo "end of build bleutooth"
