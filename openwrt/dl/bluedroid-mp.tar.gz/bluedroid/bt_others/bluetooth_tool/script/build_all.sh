export Script_Dir=$(pwd)

if [ "$#" -eq "1" ]; then
  Platform=$1
  echo "Platform is $Platform"

if [ $Platform = "MT7622" ]; then
  tmp_CC=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-gcc
  tmp_CXX=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-g++
  tmp_STRIP=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-strip
  tmp_CHIP_ID=-DMTK_MT7622
elif [ $Platform = "MT7628" ]; then
  tmp_CC=/opt/buildroot-gcc492_mips_glibc/usr/bin/mipsel-linux-gcc
  tmp_CXX=/opt/buildroot-gcc492_mips_glibc/usr/bin/mipsel-linux-g++
  tmp_STRIP=/opt/buildroot-gcc492_mips_glibc/usr/bin/mipsel-linux-strip
  tmp_CHIP_ID=-DMTK_MT7628
else
  tmp_CC=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-gcc
  tmp_CXX=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-g++
  tmp_STRIP=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-strip
  tmp_CHIP_ID=-DMTK_MT7622
fi
#project related path, integrator should care these path
#BT_Tmp_Path is used for temporay path like as /tmp
export BT_Tmp_Path=/tmp
#BT_Misc_Path is used for misc path like as /misc
export BT_Misc_Path=/etc_ro
#BT_Misc_Path is used for etc path like as /etc
export BT_Etc_Path=/data/etc
fi

if [ "$#" -eq "4" ]; then
  Platform=$1
  param_CC=$2
  param_CXX=$3
  param_STRIP=$4
  echo ${Script_Dir%/build_dir*}
  lede_root=${Script_Dir%/build_dir*}
  echo "Platform is $Platform"
  echo "param_CC is $param_CC"
  echo "param_CXX is $param_CXX"
  echo "param_STRIP is $param_STRIP"
  echo "lede_root is $lede_root"

if [ $param_CC = "aarch64-openwrt-linux-gnu-gcc" ]; then
  tmp_CC=$lede_root/staging_dir/toolchain-aarch64_cortex-a53+neon-vfpv4_gcc-5.4.0_glibc-2.24/bin/$param_CC
  tmp_CXX=$lede_root/staging_dir/toolchain-aarch64_cortex-a53+neon-vfpv4_gcc-5.4.0_glibc-2.24/bin/$param_CXX
  tmp_STRIP=$lede_root/staging_dir/toolchain-aarch64_cortex-a53+neon-vfpv4_gcc-5.4.0_glibc-2.24/bin/$param_STRIP
  tmp_CHIP_ID=-DMTK_MT7622
elif [ $Platform = "MT7628" ]; then
  tmp_CC=/opt/buildroot-gcc492_mips_glibc/usr/bin/mipsel-linux-gcc
  tmp_CXX=/opt/buildroot-gcc492_mips_glibc/usr/bin/mipsel-linux-g++
  tmp_STRIP=/opt/buildroot-gcc492_mips_glibc/usr/bin/mipsel-linux-strip
  tmp_CHIP_ID=-DMTK_MT7628
elif [ $Platform = "MT7622" ]; then
  tmp_CC=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-gcc
  tmp_CXX=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-g++
  tmp_STRIP=/opt/buildroot-gcc492_arm64/usr/bin/aarch64-linux-strip
  tmp_CHIP_ID=-DMTK_MT7622
else
  tmp_CC=$param_CC
  tmp_CXX=$param_CXX
  tmp_STRIP=$param_STRIP
  tmp_CHIP_ID="-D$Platform"
fi
#project related path, integrator should care these path
#BT_Tmp_Path is used for temporay path like as /tmp
export BT_Tmp_Path=/tmp
#BT_Misc_Path is used for misc path like as /misc
export BT_Misc_Path=/etc
#BT_Misc_Path is used for etc path like as /etc
export BT_Etc_Path=/data/etc
fi

export CC=$tmp_CC
export CXX=$tmp_CXX
export STRIP=$tmp_STRIP
export CHIP_ID=$tmp_CHIP_ID
echo "CC is $CC"

if [[ $(pwd) =~ "script/common" ]]; then
  export Bluetooth_Tool_Dir=${Script_Dir}/../..
else
  export Bluetooth_Tool_Dir=${Script_Dir}/..
fi

export Bluetooth_Stack_Dir=${Bluetooth_Tool_Dir}/../../bt_stack/bluedroid_turnkey
export Bluetooth_Mw_Dir=${Bluetooth_Tool_Dir}/../bluetooth_mw
if [ $Platform = "HCI_TYPE" ]; then
  echo "vendor_lib is hci type"
  export Bluetooth_Vendor_Lib_Dir=${Bluetooth_Tool_Dir}/../vendor_lib_hci
else
  echo "vendor_lib is stpbt type"
  export Bluetooth_Vendor_Lib_Dir=${Bluetooth_Tool_Dir}/../vendor_lib
fi
export Bluetooth_Prebuilts_Dir=${Bluetooth_Tool_Dir}/prebuilts
export Bluedroid_Libs_Path=${Bluetooth_Tool_Dir}/prebuilts/lib

#stack config file path:bt_stack.conf,bt_did.conf
export Conf_Path=${BT_Misc_Path}/bluedroid
#stack record file path.
export Cache_Path=${BT_Misc_Path}
#mw record file path, should the same with stack record path.
export Storage_Path=${BT_Misc_Path}
#system library file path:libbluetooth.default.so...
export Platform_Libs_Path=${Bluetooth_Tool_Dir}/../../../lib
##########for different platform only need modify above export variable##########
#for uhid.h depend on kernel version
export Linux_Kernel_Version=kernel-4.4

echo "start build vendor lib"
sh build_vendorlib.sh
if [ ! -f ${Bluetooth_Prebuilts_Dir}/lib/libbt-vendor.so ]; then
    echo build libbt-vendor.so failed, EXIT!
    exit
fi
echo "end build vendor lib"

echo "start build stack"
sh build_stack.sh
if [ ! -f ${Bluetooth_Prebuilts_Dir}/lib/libbluetooth.default.so ]; then
  echo build libbluetooth.default.so failed, EXIT!
  exit
fi
if [ ! -f ${Bluetooth_Prebuilts_Dir}/lib/libaudio.a2dp.default.so ]; then
  echo build libaudio.a2dp.default.so failed, EXIT!
  exit
fi
#if [ ! -f ${Bluetooth_Prebuilts_Dir}/lib/libz.so ]; then
#  echo copy libz.so failed, EXIT!
#  exit
#fi

if [ ! -f ${Bluetooth_Prebuilts_Dir}/conf/bt_stack.conf ]; then
  echo copy bt_stack.conf failed, EXIT!
  exit
fi
if [ ! -f ${Bluetooth_Prebuilts_Dir}/conf/bt_did.conf ]; then
  echo copy bt_did.conf failed, EXIT!
  exit
fi

#echo "start build btut"
#sh build_btut.sh
#if [ ! -f ${Bluetooth_Prebuilts_Dir}/bin/btut ]; then
#  echo build btut failed, EXIT!
#  exit
#fi

echo "start build picus"
sh build_picus.sh
if [ ! -f ${Bluetooth_Prebuilts_Dir}/bin/picus ]; then
  echo build picus failed, EXIT!
  exit
fi

echo "start build boots"
sh build_boots.sh
if [ ! -f ${Bluetooth_Prebuilts_Dir}/bin/boots ]; then
  echo build boots failed, EXIT!
  exit
fi

echo "start build mw"
sh build_mw.sh
if [ ! -f ${Bluetooth_Prebuilts_Dir}/lib/libbt-mw.so ]; then
  echo build libbt-mw.so failed, EXIT!
  exit
fi

#echo "start build playback"
#sh build_playback.sh
#if [ ! -f ${Bluetooth_Prebuilts_Dir}/lib/libbt-alsa-playback.so ]; then
#  echo build libbt-alsa-playback.so failed, EXIT!
#  exit
#fi

#######################################--Begin RPC--########################################
#echo "start build build_mtk_rpcipc lib"
#sh build_mtk_rpcipc.sh
#if [ ! -f ${Bluetooth_Prebuilts_Dir}/lib/libipcrpc.so ]; then
#    echo build libipcrpc.so failed, EXIT!
#    exit
#fi
#
#echo "start build build_rpcipc_bt_service"
#sh build_rpcipc_bt_service.sh
#if [ ! -f ${Bluetooth_Prebuilts_Dir}/lib/libmtk_bt_service_server.so ]; then
#    echo build libmtk_bt_service_server.so failed, EXIT!
#    exit
#fi
#if [ ! -f ${Bluetooth_Prebuilts_Dir}/lib/libmtk_bt_service_client.so ]; then
#    echo build libmtk_bt_service_client.so failed, EXIT!
#    exit
#fi
#
#echo "start build build_mw_rpc_test"
#sh build_mw_rpc_test.sh
#if [ ! -f ${Bluetooth_Prebuilts_Dir}/bin/btmw-rpc-test ]; then
#    echo build btmw-rpc-test failed, EXIT!
#    exit
#fi
#
#echo "start build build_btservice"
#sh build_btservice.sh
#if [ ! -f ${Bluetooth_Prebuilts_Dir}/bin/btservice ]; then
#    echo build btservice failed, EXIT!
#    exit
#fi
#######################################--End RPC--########################################

echo "start build demo"
sh build_mwtest.sh
if [ ! -f ${Bluetooth_Prebuilts_Dir}/bin/btmw-test ]; then
  echo build btmw-test failed, EXIT!
  exit
fi

#echo "start collect bluetooth lib, conf, bin"
#sh bt_collect.sh

cd ${Script_Dir}
