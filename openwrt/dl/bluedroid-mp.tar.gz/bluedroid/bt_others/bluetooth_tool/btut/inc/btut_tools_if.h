#ifndef __BTUT_TOOLS_IF_H__
#define __BTUT_TOOLS_IF_H__

#define CMD_KEY_TOOLS     "TOOLS"

int btut_tools_init();

#endif /* __BTUT_TOOLS_IF_H__ */
