#ifndef __BTUT_A2DP_SINK_IF_H__
#define __BTUT_A2DP_SINK_IF_H__

#define CMD_KEY_A2DP_SINK        "A2DP_SINK"

int btut_a2dp_sink_init();
int btut_a2dp_sink_deinit();

#endif /* __BTUT_A2DP_SINK_IF_H__ */
