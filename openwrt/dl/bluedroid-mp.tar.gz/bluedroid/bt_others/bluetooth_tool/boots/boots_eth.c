/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * MediaTek Inc. (C) 2016~2017. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <errno.h>
#include <string.h>
#include <stddef.h>
#include <unistd.h>

#include <sys/socket.h>
#include <sys/ioctl.h> /* sock ioctl */
#include <sys/select.h>
#include <net/if.h>    /* ifreq */
#include <net/ethernet.h> /* sockaddr_ll */
#include <netinet/in.h>
#include <netpacket/packet.h>


#include "boots.h"
#include "boots_eth.h"
#include "boots_pkt.h"

//---------------------------------------------------------------------------
#define LOG_TAG "boots_eth"

#define ETH_PORT_SIZE   (5)
#define ETH_HDR_SIZE    14

static int if_index;
unsigned short eth_protocol = 0x7623;
static char *eth_port[ETH_PORT_SIZE] = {"br0", "br-lan", "eth0", "eth1", "eth2"};
static const char broadcast_addr[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
static char my_eth_addr[6];

//---------------------------------------------------------------------------
int boots_eth_create(int * sk, struct sockaddr_in * sockaddr, int client)
{
    UNUSED(boots_btif);

    // Create server socket
    *sk = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (*sk < 0) {
        BPRINT_E("Create socket failed: %s(%d)", strerror(errno), errno);
        return errno;
    }

    // Init server socket
    if (!client) {
        memset(sockaddr, 0, sizeof(struct sockaddr_in));
        sockaddr->sin_family = AF_INET;
        sockaddr->sin_port = ETH_UDP_SRV_PORT;
        sockaddr->sin_addr.s_addr = INADDR_ANY;
        if (bind(*sk, (struct sockaddr *)sockaddr, sizeof(struct sockaddr)) < 0) {
            BPRINT_E("Bind socket failed: %s(%d)", strerror(errno), errno);
            return errno;
        }
    }

    BPRINT_D("Socket %s create success", client ? "Client" : "Server");
    return 0;
}

//---------------------------------------------------------------------------
int boots_eth_close(int * sk)
{
    if (sk == NULL) {
        BPRINT_E("%s: Incorrect socket", __func__);
        return -1;
    }
    close(*sk);
    *sk = -1;
    return 0;
}

//---------------------------------------------------------------------------
ssize_t boots_eth_send(int s, const void * buf, size_t len, struct sockaddr_in * to)
{
    ssize_t ret = 0;

    if (!buf || !len) {
        BPRINT_E("%s: Incorrect parameters", __func__);
        return -1;
    }
#if 1
    ret = sendto(s, buf, len, 0, (const struct sockaddr *)to,
            sizeof(struct sockaddr));
#else
    ret = send(s, buf, len, 0);
#endif
    if (ret < 0)
        BPRINT_E("%s: Send message failed: %s(%d)", __func__, strerror(errno), errno);

    return ret;
}

//---------------------------------------------------------------------------
ssize_t boots_eth_recv(int s, const void * buf, size_t len, int flags)
{
    ssize_t ret = 0;
    struct sockaddr srcaddr;
    socklen_t srcaddr_len = sizeof(struct sockaddr);

    if (!buf || !len) {
        BPRINT_E("%s: Incorrect parameters", __func__);
        return -1;
    }

    ret = recvfrom(s, (void *)buf, len, flags, &srcaddr, &srcaddr_len);
    if (ret < 0)
        BPRINT_E("%s: Receive message failed: %s(%d)", __func__, strerror(errno), errno);

    return ret;
}

int boots_eth_relayer_create(int * sk)
{
    struct ifreq ifr;
    struct sockaddr_ll addr;
    int i = 0;

    if ((*sk=socket(PF_PACKET, SOCK_RAW, htons(eth_protocol))) < 0)
    {
        BPRINT_E("Create socket failed: %s(%d)", strerror(errno), errno);
        return errno;
    }

    for (i = 0 ; i < ETH_PORT_SIZE ; i++) {
        memset(&ifr, 0, sizeof(ifr));
        memcpy(ifr.ifr_name, eth_port[i], strlen(eth_port[i]));
        BPRINT_D("ifr.ifr_name=\"%s\"\n", ifr.ifr_name);
        ioctl(*sk, SIOCGIFFLAGS, &ifr);
        if (ifr.ifr_flags & IFF_UP) {
            BPRINT_I("%s is up!\n", eth_port[i]);
            break;
        }
    }

    if (i == ETH_PORT_SIZE) {
        BPRINT_E("No ethernet interface find!!\n");
        goto close;
    }

    if (ioctl(*sk, SIOCGIFINDEX, &ifr) != 0)
    {
        BPRINT_E("[%s]ioctl(SIOCGIFINDEX)(eth_sock)", __FUNCTION__);
        goto close;
    }

    memset(&addr, 0, sizeof(addr));
    addr.sll_family = AF_PACKET;
    addr.sll_ifindex = ifr.ifr_ifindex;
    if_index = ifr.ifr_ifindex;

    if (bind(*sk, (struct sockaddr *) &addr, sizeof(addr)) < 0)
    {
        BPRINT_E("[%s]bind error\n", __FUNCTION__);
        goto close;
    }

    if (ioctl(*sk, SIOCGIFHWADDR, &ifr) != 0)
    {
        BPRINT_E("[%s]ioctl(SIOCGIFHWADDR)(eth_sock)", __FUNCTION__);
        goto close;
    }

    memcpy(my_eth_addr, ifr.ifr_hwaddr.sa_data, 6);

    return *sk;

close:
    close(*sk);
    *sk = -1;
    return *sk;
}

//---------------------------------------------------------------------------
int boots_eth_relayer_close(int * sk)
{
    if (sk == NULL) {
        BPRINT_E("%s: Incorrect socket", __func__);
        return -1;
    }
    close(*sk);
    *sk = -1;
    return 0;
}

//---------------------------------------------------------------------------
ssize_t boots_eth_relayer_send(int s, const void * buf, size_t len)
{
    unsigned char eth_pkt[1536];
    struct ethhdr *p_ehead;
    struct sockaddr_ll skt_addr;

    if (s < 0)
        return -1;

    memset(&eth_pkt[0], 0, 1536);

    p_ehead = (struct ethhdr *)&eth_pkt[0];

    memcpy(&eth_pkt[14], buf, len);
    memcpy(p_ehead->h_dest,   broadcast_addr, 6);
    memcpy(p_ehead->h_source, my_eth_addr, 6);
    p_ehead->h_proto = htons(eth_protocol);

    if ((len + ETH_HDR_SIZE) < 60 )
    {
        len = 60 - ETH_HDR_SIZE;
    } else if (len > 1514 )
    {
        BPRINT_E("response ethernet length is too long\n");
        return -1;
    }

    skt_addr.sll_family = PF_PACKET;
    skt_addr.sll_protocol = eth_protocol;//ETH_P_RACFG;
    skt_addr.sll_ifindex = if_index;
    skt_addr.sll_pkttype = PACKET_BROADCAST;
    skt_addr.sll_hatype = 1;
    skt_addr.sll_halen = 6;/*ETH_ADDR_SIZE*/;

    memset(&skt_addr.sll_addr[0], 0, 8);
    memcpy(&skt_addr.sll_addr[0], broadcast_addr, 6);

    if (sendto(s, eth_pkt, len + ETH_HDR_SIZE, 0, (struct sockaddr *)&skt_addr, sizeof(skt_addr)) < 0)
        BPRINT_E("%s: Send message failed: %s(%d)", __func__, strerror(errno), errno);

    return 0;
}

//---------------------------------------------------------------------------
ssize_t boots_eth_relayer_recv(int s, const void * buf, size_t len)
{
    int bytesRead;
    int bytesToRead;
    fd_set readfd;
    struct ethhdr *p_ehead;
    unsigned char packet[1536];

    if (s < 0)
        return -1;

    FD_ZERO(&readfd);
    FD_SET(s, &readfd);

    //count = select(sock+1,&readfds,NULL,NULL,&tv);
    if (select(s + 1, &readfd, NULL, NULL, NULL) <= 0)
    {
        BPRINT_E("%s: select failed: %s(%d)", __func__, strerror(errno), errno);
        return -1;
    } else {
        if (FD_ISSET(s, &readfd))
        {
            if ((bytesRead = recvfrom(s, packet, sizeof(packet), 0, NULL, NULL)) > 0){

                p_ehead = (struct ethhdr *) &packet[0];
                if (p_ehead->h_proto == htons(eth_protocol)){
                    BPRINT_D("rcv_protocol=[%x], ntohs(ETH_P_RACFG)=[%x]\n", p_ehead->h_proto, eth_protocol);
                    BPRINT_D("Receive packet[%d] from PC.\n", bytesRead);
                } else {
                    BPRINT_D("Receive the packet we do not care\n");
                }

                if (packet[ETH_HDR_SIZE] == HCI_CMD_PKT)
                    bytesToRead = packet[ETH_HDR_SIZE + 3] + HCI_CMD_PKT_HDR_LEN;
                else if (packet[ETH_HDR_SIZE] == HCI_ACL_PKT)
                    bytesToRead = (packet[ETH_HDR_SIZE + 4] << 8) + packet[ETH_HDR_SIZE + 3] + HCI_ACL_PKT_HDR_LEN;

                memcpy((void *)buf, packet + ETH_HDR_SIZE, bytesToRead);
            } else {
                return -1;
            }
        }
    }

    return bytesToRead;
}

